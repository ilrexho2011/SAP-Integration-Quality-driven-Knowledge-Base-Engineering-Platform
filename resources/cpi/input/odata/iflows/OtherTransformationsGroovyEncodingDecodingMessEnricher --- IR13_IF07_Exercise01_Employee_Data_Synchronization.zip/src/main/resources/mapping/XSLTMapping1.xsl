<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" indent="yes"/>
    
    <xsl:template match="/">
        <Employees>
            <xsl:apply-templates select="Employees/Employee"/>
        </Employees>
    </xsl:template>

    <xsl:template match="Employee">
        <Employee>
            <xsl:apply-templates select="ID"/>
            <ProcessingID>HR-SYNC-2025</ProcessingID>
            <xsl:apply-templates select="Name | Status | Salary"/>
        </Employee>
    </xsl:template>

    <xsl:template match="*">
        <xsl:copy>
            <xsl:apply-templates select="@* | node()"/>
        </xsl:copy>
    </xsl:template>
</xsl:stylesheet>
