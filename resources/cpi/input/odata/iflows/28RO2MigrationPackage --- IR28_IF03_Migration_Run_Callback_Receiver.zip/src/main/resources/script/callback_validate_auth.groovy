import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    def authHeader = message.getHeader("Authorization", String)
    def expected = message.getProperty("CALLBACK_EXPECTED_AUTH") as String
    if (!expected) throw new IllegalStateException("Missing CALLBACK_EXPECTED_AUTH")
    if (!authHeader || authHeader != expected) {
        throw new SecurityException("Unauthorized callback request")
    }
    return message
}
