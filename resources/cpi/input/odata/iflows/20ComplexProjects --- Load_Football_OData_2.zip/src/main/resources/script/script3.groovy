import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def properties = message.getProperties()
    def Home = properties.get("Home")
    def Away = properties.get("Away")
    def myDate = properties.get("Date")

    def myErr = "File with error contained ${Home} v ${Away} on ${myDate}\n\n\n"

    message.setProperty("ErrorMessage2", myErr)

    return message;
}