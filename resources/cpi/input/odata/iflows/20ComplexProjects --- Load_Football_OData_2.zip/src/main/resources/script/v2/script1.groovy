// This is Groovy Flowstep Version 2.x, running with Groovy runtime 4, Downgrade the script if older behaviour needed.

// Groovy Flowstep Version 2.x (Groovy runtime 4)

import com.sap.it.script.v2.api.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def properties = message.getProperties()

    // Now
    Date now = new Date()
    def dateFmt = new SimpleDateFormat("dd/MM/yyyy")
    def timeFmt = new SimpleDateFormat("HH:mm:ss")

    // Properties (null-safe)
    String progID = (properties.get("progID") ?: "").toString()
    String errorDetails = (properties.get("ErrorMessage") ?: "").toString()
    String fileNameRaw = (properties.get("CamelFileExchangeFile") ?: "").toString()

    // Clean file name if it comes like RemoteFile[...]
    String fileNameClean = fileNameRaw
    if (fileNameClean?.startsWith("RemoteFile[")) {
        fileNameClean = fileNameClean.replace("RemoteFile[", "").replace("]", "")
    }

    StringBuilder out = new StringBuilder()
    out.append("There was an error in Iflow : ").append(progID).append("\n\n")
    out.append("This error happened at ").append(timeFmt.format(now))
       .append(" on ").append(dateFmt.format(now)).append("\n\n")

    if (fileNameClean?.trim()) {
        out.append("The file Name was : ").append(fileNameClean).append("\n\n")
    }

    out.append("Error details : ").append(errorDetails)

    message.setBody(out.toString())
    return message
}