import com.sap.it.script.v2.api.Message

def Message processData(Message message) {

    String body = (message.getBody(String) ?: "")
    def props = message.getProperties()

    String doDel = (props.get("delFlag") ?: "").toString()
    boolean gotIt = body.contains("Home")

    String toDo = gotIt ? "PUT" : "POST"

    if (doDel == "Y") {
        if (toDo == "PUT") {
            toDo = "DELETE"
        } else {
            toDo = "FAIL"
        }
    }

    message.setProperty("toDo", toDo)

    String savedBody = (props.get("savedBody") ?: "").toString()
    message.setBody(savedBody)

    return message
}