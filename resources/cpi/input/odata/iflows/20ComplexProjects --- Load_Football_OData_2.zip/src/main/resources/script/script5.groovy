import com.sap.it.script.v2.api.Message

def Message processData(Message message) {

    message.setProperty("ErrorType", "DELETE_NOT_FOUND")

    throw new Exception("""
There was an attempt to delete a Score that is not in the database
""")
}