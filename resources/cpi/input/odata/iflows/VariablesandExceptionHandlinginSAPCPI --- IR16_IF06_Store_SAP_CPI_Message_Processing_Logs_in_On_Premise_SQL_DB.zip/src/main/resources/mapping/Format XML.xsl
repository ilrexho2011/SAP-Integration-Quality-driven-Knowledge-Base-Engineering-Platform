<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:m="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata" xmlns:d="http://schemas.microsoft.com/ado/2007/08/dataservices" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge" exclude-result-prefixes="atom m d xsl multimap">
	<xsl:strip-space elements="*"/>
	<xsl:output indent="yes" omit-xml-declaration="no" media-type="application/xml" encoding="UTF-8"/>
	<xsl:template match="multimap:Message1">
		<MessageProcessingLogs>
			<!-- Loop over each MessageProcessingLog entry independently -->
			<xsl:for-each select="//MessageProcessingLogs/MessageProcessingLog">
				<Records>
				    <MessageID>
						<xsl:value-of select="MessageGuid"/>
					</MessageID>
				    <CorrelationID>
						<xsl:value-of select="CorrelationId"/>
					</CorrelationID>
					<ApplicationMessageId>
						<xsl:value-of select="ApplicationMessageId"/>
					</ApplicationMessageId>
					<Status>
						<xsl:value-of select="Status"/>
					</Status>
					<IntegrationFlowName>
						<xsl:value-of select="IntegrationArtifact/Name"/>
					</IntegrationFlowName>
					<PackageName>
						<xsl:value-of select="IntegrationArtifact/PackageName"/>
					</PackageName>
					<LogTime>
						<xsl:value-of select="LogEnd"/>
					</LogTime>
					<ExceptionMessage>
						<xsl:value-of select="../ErrorText"/>
					</ExceptionMessage>
					<MonitorLink>
						<xsl:value-of select="AlternateWebLink"/>
					</MonitorLink>
				</Records>
			</xsl:for-each>
		</MessageProcessingLogs>
	</xsl:template>
	<!-- Default templates to do nothing -->
	<xsl:template match="text()" priority="-100"/>
</xsl:stylesheet>