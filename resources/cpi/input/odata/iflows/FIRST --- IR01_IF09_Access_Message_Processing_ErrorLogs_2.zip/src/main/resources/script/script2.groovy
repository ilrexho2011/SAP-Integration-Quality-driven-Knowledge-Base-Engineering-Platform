import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    String messageGuid = (message.getProperty("MessageGuid") ?: "").toString()
    String logStart = (message.getProperty("LogStart") ?: "").toString()
    String logEnd = (message.getProperty("LogEnd") ?: "").toString()
    String sender = (message.getProperty("Sender") ?: "").toString()
    String receiver = (message.getProperty("Receiver") ?: "").toString()
    String integrationFlowName = (message.getProperty("IntegrationFlowName") ?: "").toString()
    String status = (message.getProperty("Status") ?: "").toString()

    String errorText = (message.getBody(String) ?: "").toString().trim()

    if (!errorText) {
        errorText = "No ErrorMessage returned by MPL API! Error details not available..."
    }

    messageGuid = escapeXml(messageGuid)
    logStart = escapeXml(logStart)
    logEnd = escapeXml(logEnd)
    sender = escapeXml(sender)
    receiver = escapeXml(receiver)
    integrationFlowName = escapeXml(integrationFlowName)
    status = escapeXml(status)
    errorText = escapeXml(errorText)

    String xml =
        "<MessageError>" +
            "<MessageGuid>" + messageGuid + "</MessageGuid>" +
            "<LogStart>" + logStart + "</LogStart>" +
            "<LogEnd>" + logEnd + "</LogEnd>" +
            "<Sender>" + sender + "</Sender>" +
            "<Receiver>" + receiver + "</Receiver>" +
            "<IntegrationFlowName>" + integrationFlowName + "</IntegrationFlowName>" +
            "<Status>" + status + "</Status>" +
            "<ErrorMessage>" + errorText + "</ErrorMessage>" +
        "</MessageError>"

    message.setHeader("Content-Type", "application/xml")
    message.setBody(xml)

    return message
}

def String escapeXml(String value) {
    return value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}