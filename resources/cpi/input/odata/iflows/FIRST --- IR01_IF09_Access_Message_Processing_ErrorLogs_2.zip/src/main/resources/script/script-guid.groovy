import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def body = message.getBody(String)
    def xml = new XmlSlurper(false, false).parseText(body)

    def guid = xml.MessageGuid.text()?.trim()

    if (!guid) {
        throw new Exception("MessageGuid not found in XML payload.")
    }

    message.setProperty("MessageGuid", guid)
    return message
}