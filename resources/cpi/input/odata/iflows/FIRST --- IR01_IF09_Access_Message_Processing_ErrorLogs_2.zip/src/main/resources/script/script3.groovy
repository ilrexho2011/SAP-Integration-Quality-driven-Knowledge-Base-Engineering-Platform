import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    String body = (message.getBody(String) ?: "").toString()

    String finalXml =
        "<MessageErrors>" +
            body +
        "</MessageErrors>"

    message.setHeader("Content-Type", "application/xml")
    message.setBody(finalXml)

    return message
}