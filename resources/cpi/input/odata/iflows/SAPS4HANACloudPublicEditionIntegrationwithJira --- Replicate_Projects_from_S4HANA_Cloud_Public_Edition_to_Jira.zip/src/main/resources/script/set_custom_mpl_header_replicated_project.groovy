import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        
        def projectName = message.getProperty("project_name") as String;
        def projectIsForUpdate = message.getProperty("projectUpdated")
        def headerMessage = projectIsForUpdate == 'true' ? "Updated Project" : "Created Project"
        if (projectName != null && !projectName.isEmpty()) {
            messageLog.addCustomHeaderProperty(headerMessage, projectName);
        }
    }
    return message;
}