import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def rawProjectFilter = message.getProperty("project_filter")

    if (rawProjectFilter) {
        def projectList = rawProjectFilter.split(',').collect { it.trim() }.findAll { !it.isEmpty() }

        if (projectList) {
            def customFilter = projectList.collect { "substringof('${it}', Project)" }.join(' or ')

            message.setProperty("custom_query_filter", "\$filter=${customFilter}".toString())
        }
    }

    return message
}