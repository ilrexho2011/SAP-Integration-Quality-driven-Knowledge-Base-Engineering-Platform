import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    
    def slurper = new JsonSlurper()
    def parsedJson = slurper.parse(body)

    def projectKey = parsedJson.key

    message.setProperty("project_key", projectKey)

    return message
}