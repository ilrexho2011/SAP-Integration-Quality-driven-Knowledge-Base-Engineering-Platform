import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def adminId = message.getProperty("jira_lead_account_id") as String

    def body = message.getBody(java.io.Reader)
    def allEmployees = new XmlSlurper().parse(body)

    def teamMembers = allEmployees.jiraEmployee.findAll { employee -> 
        def uid = employee.userID.text()
        uid && uid != adminId
    }

    def userIdList = teamMembers.collect { member ->
        member.userID.text()
    }

    if (userIdList.size() == 0) {
        message.setProperty("is_empty_users", true)
    }

    def finalMap = [user: userIdList]

    message.setBody(new JsonBuilder(finalMap).toString())
    return message
}