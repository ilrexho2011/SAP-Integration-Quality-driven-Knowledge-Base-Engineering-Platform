import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.xml.StreamingMarkupBuilder

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def project = new XmlSlurper().parse(body)
    
    def teamMember = project.A_EnterpriseProjectType.to_EntProjTeamMember.A_EnterpriseProjectTeamMemberType
    def bpUUID = teamMember.BusinessPartnerUUID.text()
    def creationDateTime = teamMember.CreationDateTime.text()

    def builder = new StreamingMarkupBuilder()
    def xmlBody = builder.bind {
        to_EntProjTeamMember() {
            A_EnterpriseProjectTeamMemberType() {
                BusinessPartnerUUID(bpUUID)
                CreationDateTime(creationDateTime)
            }
        }
    }

    message.setBody(xmlBody.toString())
    
    return message
}