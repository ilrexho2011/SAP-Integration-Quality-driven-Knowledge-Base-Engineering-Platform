import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def jiraLeadId = message.getProperty("jira_lead_account_id")
    def body = message.getBody(java.io.Reader)
    
    def slurper = new JsonSlurper()
    def parsedJson = slurper.parse(body)

    def leadAlreadyAddedToRole = parsedJson.actors.any { actor -> 
        actor.actorUser.accountId == jiraLeadId
    }

    message.setProperty("lead_already_added_to_role", leadAlreadyAddedToRole)

    return message
}