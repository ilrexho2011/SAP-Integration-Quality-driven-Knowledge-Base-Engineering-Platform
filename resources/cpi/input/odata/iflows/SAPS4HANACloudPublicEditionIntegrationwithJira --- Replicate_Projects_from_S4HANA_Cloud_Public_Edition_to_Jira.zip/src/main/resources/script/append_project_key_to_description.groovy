import com.sap.gateway.ip.core.customdev.util.Message
import org.apache.commons.lang3.StringEscapeUtils

def Message processData(Message message) {
    def projectDescription = message.getProperty("project_description") ?: ""
    def projectKey = message.getProperty("project_key") ?: ""

    final int MAX_LENGTH = 40
    final String ELLIPSIS = "..."

    def suffix = " JK: ${projectKey}"
    
    def finalDescription
    if ((projectDescription.length() + suffix.length()) <= MAX_LENGTH) {
        finalDescription = projectDescription + suffix
    } else {
        def availableDescLength = MAX_LENGTH - suffix.length() - ELLIPSIS.length()

        def trimmedDescription = projectDescription.take(availableDescLength)
        finalDescription = trimmedDescription + ELLIPSIS + suffix
    }

    String safeDescription = StringEscapeUtils.escapeXml10(finalDescription)

    message.setProperty("linked_description", safeDescription)

    return message
}