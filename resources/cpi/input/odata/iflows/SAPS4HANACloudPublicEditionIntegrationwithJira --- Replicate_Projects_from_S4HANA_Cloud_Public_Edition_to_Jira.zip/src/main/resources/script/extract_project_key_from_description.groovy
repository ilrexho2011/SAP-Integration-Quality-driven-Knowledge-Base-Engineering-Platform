import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def JIRA_KEY_PREFIX = "JK:"
    def projectDescription = message.getProperty("project_description") ?: ""

    if (projectDescription.contains(JIRA_KEY_PREFIX)) {
        def projectKey = projectDescription.split(JIRA_KEY_PREFIX)[1].trim()
        def projectDescriptionWithoutProjectKey = projectDescription.split(JIRA_KEY_PREFIX)[0].trim()
        message.setProperty("linked_project_key", projectKey)
        message.setProperty("projectDescriptionWithoutProjectKey", projectDescriptionWithoutProjectKey)
    }

    return message
}