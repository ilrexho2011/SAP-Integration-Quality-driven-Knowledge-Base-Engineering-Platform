import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def preferredRoleKey = message.getProperty("jira_preferred_project_role")
    def defaultRoleKey = message.getProperty("jira_default_project_role")
    def adminRoleKey = "administrator"

    def body = message.getBody(java.io.Reader)
    def projectRoles = new JsonSlurper().parse(body)
    def hasPreferredRole = true
    def roleUrl = projectRoles.find { entry -> entry.key.equalsIgnoreCase(preferredRoleKey) }?.value

    if (!roleUrl) {
        roleUrl = projectRoles.find { entry -> entry.key.equalsIgnoreCase(defaultRoleKey) }?.value
        hasPreferredRole = false
    }

    if (!roleUrl) {
        roleUrl = projectRoles.find { entry -> entry.key.toLowerCase().contains(adminRoleKey) }?.value
    }

    if (!roleUrl) {
        message.setProperty("no_roles_matching", true)
        return message
    }

    def roleId = ""
    if (roleUrl) {
        roleId = getRoleId(roleUrl)
    }
    
    message.setProperty("role_id", roleId)
    message.setProperty("admin_role_id", getAdminRoleId(projectRoles))
    message.setProperty("has_preferred_role", hasPreferredRole)
    return message
}

def String getAdminRoleId(def rolesJson) {
    def adminRoleUrl = rolesJson.find { entry -> entry.key.toLowerCase().contains("dministrator") }?.value
    return getRoleId(adminRoleUrl)
}

def String getRoleId(String roleUrl) {
    return roleUrl.split("/")[-1]
}