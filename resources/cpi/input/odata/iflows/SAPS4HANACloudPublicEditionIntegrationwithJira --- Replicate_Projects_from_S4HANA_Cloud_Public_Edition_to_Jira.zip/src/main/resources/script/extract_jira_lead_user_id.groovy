import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def jiraEmployee = new XmlSlurper().parse(body)
    def userID = jiraEmployee.userID.text()

    if (!userID || userID.trim().isEmpty()) {
        message.setProperty("pm_missing", true)
        return message
    }

    message.setProperty("jira_lead_account_id", userID)
    return message
}