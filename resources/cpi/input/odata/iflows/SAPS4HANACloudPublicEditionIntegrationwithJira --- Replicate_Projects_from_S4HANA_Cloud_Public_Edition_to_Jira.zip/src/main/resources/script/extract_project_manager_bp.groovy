import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.xml.StreamingMarkupBuilder

def Message processData(Message message) {
    def PROJECT_MANAGER_ROLE_TYPE = message.getProperty("project_manager_role") as String
    def xmlPayload = message.getBody(java.io.Reader)
    def project = new XmlSlurper().parse(xmlPayload)

    def teamMembers = project.A_EnterpriseProjectType.to_EntProjTeamMember.A_EnterpriseProjectTeamMemberType
    def projectPM = teamMembers.find { member ->
        member.to_EntProjEntitlement.A_EntTeamMemberEntitlementType.ProjectRoleType.any { role ->
            role.text() == PROJECT_MANAGER_ROLE_TYPE
        }
    }

    if (!projectPM) {
        message.setProperty("pm_missing", true)
        return message
    }

    def bpUUID = projectPM.BusinessPartnerUUID.text()
    def creationDateTime = projectPM.CreationDateTime.text()

    def builder = new StreamingMarkupBuilder()
    def xmlBody = builder.bind {
        to_EntProjTeamMember() {
            A_EnterpriseProjectTeamMemberType() {
                BusinessPartnerUUID(bpUUID)
                CreationDateTime(creationDateTime)
            }
        }
    }

    message.setBody(xmlBody.toString())
    
    return message
}