import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        def projectFilter = message.getProperty("project_filter") ?: ""
        def deltaTimestamp = message.getProperty("current_execution_last_processed_project_updated_at_timestamp") as String
        
        def fullFilterQuery = "LastChangeDateTime ge datetimeoffset'$deltaTimestamp' $projectFilter"
        messageLog.addCustomHeaderProperty("Projects not found matching filter", fullFilterQuery)
    }
    return message
}