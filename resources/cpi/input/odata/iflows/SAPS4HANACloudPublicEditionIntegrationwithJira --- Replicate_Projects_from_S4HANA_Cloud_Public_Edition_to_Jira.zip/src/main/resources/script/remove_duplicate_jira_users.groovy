import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def jiraUsersForRoleRaw = message.getProperty("jira_users_for_role") as String
    def body = message.getBody(java.io.Reader)

    def slurper = new JsonSlurper()
    def projectRole = slurper.parse(body)
    def jiraUsersForRole = slurper.parseText(jiraUsersForRoleRaw).user

    def existingUserIds = projectRole.actors*.actorUser.accountId as Set

    def usersToAdd = jiraUsersForRole.findAll { user ->
        !existingUserIds.contains(user)
    }

    if (usersToAdd.size() == 0) {
        message.setProperty("is_empty_users", true)
    }
    def result = [user: usersToAdd]

    message.setBody(new JsonBuilder(result).toString())
    
    return message
}