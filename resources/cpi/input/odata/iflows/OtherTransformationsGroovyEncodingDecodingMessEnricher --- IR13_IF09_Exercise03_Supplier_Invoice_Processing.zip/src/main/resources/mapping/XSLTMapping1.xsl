<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="xml" indent="yes"/>
    <xsl:template match="/">
        <Invoices>
            <xsl:for-each select="Invoices/Invoice">
                <Invoice>
                    <ID><xsl:value-of select="ID"/></ID>
                    <Supplier><xsl:value-of select="Supplier"/></Supplier>
                    <ApprovalStatus>Pending</ApprovalStatus>
                    <Amount><xsl:value-of select="Amount"/></Amount>
                </Invoice>
            </xsl:for-each>
        </Invoices>
    </xsl:template>
</xsl:stylesheet>
