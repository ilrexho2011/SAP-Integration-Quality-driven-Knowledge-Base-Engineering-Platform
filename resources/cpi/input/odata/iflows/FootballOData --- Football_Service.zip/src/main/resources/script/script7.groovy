import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper



def Message processData(Message message) {
    def body = message.getBody(String);
    properties = message.getProperties()
    
    scoresService = properties.get("scoresService")
    pad = " "
    theLeague = pad.padRight(25) + " Plyd  Won  Drawn  Lost  For  Against    Goal Diff    Points\n"

    def League = new XmlSlurper().parseText(body)
    myLeague = League.Table.collect{it}
    
    
    
    x=0
    for (item in myLeague) {
        theLeague += myLeague[x].Team.text().replace("_"," ").padRight(25) + myLeague[x].Played.toString().padLeft(4) + myLeague[x].Won.toString().padLeft(6) + myLeague[x].Drawn.toString().padLeft(6) + myLeague[x].Lost.toString().padLeft(6) + myLeague[x].For.toString().padLeft(6) + myLeague[x].Against.toString().padLeft(6) + myLeague[x].GoalDiff.toString().padLeft(13) + myLeague[x].Points.toString().padLeft(11) + "\n"
        x++
    }

    theLeague += "\n\n\n" + scoresService

    message.setBody(theLeague)
    return message;
}