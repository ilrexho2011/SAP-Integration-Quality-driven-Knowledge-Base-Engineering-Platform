// This is Groovy Flowstep Version 2.x, running with Groovy runtime 4, Downgrade the script if older behaviour needed.

import com.sap.it.script.v2.api.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def properties = message.getProperties()

    // Dates
    Date now = new Date()
    SimpleDateFormat theDate = new SimpleDateFormat("dd/MM/yyyy")
    SimpleDateFormat theTime = new SimpleDateFormat("HH:mm:ss")

    // Read properties (null-safe)
    String progID        = (properties.get("progID") ?: "").toString()
    String errorDetails  = (properties.get("ErrorMessage") ?: "").toString()
    String errorDetails2 = (properties.get("ErrorMessage2") ?: "").toString()

    // Prefer ErrorMessage2 if present, otherwise ErrorMessage
    String finalError = (errorDetails2?.trim() ? errorDetails2 : errorDetails)

    // File name property: try common variants
    String fileNameRaw = (
        properties.get("CamelFileNameExchangeFile") ?:
        properties.get("CamelFileExchangeFile") ?:
        properties.get("CamelFileName") ?:
        ""
    ).toString()

    // Normalize file name (RemoteFile[...] OR plain path/name)
    String fileName = ""
    if (fileNameRaw?.trim()) {

        // Extract inside RemoteFile[...] if present (no indexing)
        def m = (fileNameRaw =~ /RemoteFile\[(.*)\]/)
        String candidate = (m.find() ? (m.group(1) ?: "") : fileNameRaw)

        // Normalize slashes and take last segment safely
        candidate = candidate.replace("\\", "/").trim()
        int lastSlash = candidate.lastIndexOf("/")
        fileName = (lastSlash >= 0 ? candidate.substring(lastSlash + 1) : candidate)  // safe: lastSlash+1 within range

        // Edge case: candidate ends with "/" -> result becomes ""
        if (!fileName?.trim()) {
            fileName = candidate
        }
    }

    // Build output
    String output = ""
    output += "There was an error in iFlow: ${progID}\n\n"
    output += "This error happened at ${theTime.format(now)} on ${theDate.format(now)}\n\n"

    if (fileName?.trim()) {
        output += "The file name was: ${fileName}\n\n"
    }

    output += "Error details: ${finalError?.trim() ? finalError : '(empty)'}"

    message.setBody(output)
    return message
}