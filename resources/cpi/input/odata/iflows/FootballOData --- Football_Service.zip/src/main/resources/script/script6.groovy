import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper
import groovy.xml.MarkupBuilder


def Message processData(Message message) {
    def body = message.getBody(String);
    Writer myXml = new StringWriter()
    def indent = new IndentPrinter(myXml, '    ')
    def rootXml = new MarkupBuilder(indent)
    
    def properties = message.getProperties()
    def myTeams = properties.get("myTeams")
    
    def Teams = new XmlSlurper().parseText(myTeams)
    def Score = new XmlSlurper().parseText(body)
    def Scores = Score.Scores.collect{it}
    
    theTeams = Teams.Teams.collect{it}
    def leagueTeams = []
    leagueTeams = theTeams.TeamName
    
    def leagueTeam    = []
    def leaguePlayed  = []
    def leagueGD      = []
    def leaguePTS     = []
    def leagueWon     = []
    def leagueDrawn   = []
    def leagueLost    = []
    def leagueFor     = []
    def leagueAgainst = []
    
    x= 0
    
    for (item in leagueTeams) {
        
        leagueTeam[x] = item.text()
        leaguePlayed[x]  = 0
        leagueGD[x]      = 0
        leaguePTS[x]     = 0
        leagueWon[x]     = 0
        leagueDrawn[x]   = 0
        leagueLost[x]    = 0
        leagueFor[x]     = 0
        leagueAgainst[x] = 0
        
        myScores = Scores.findAll{it.HomeTeam == item || it.AwayTeam == item }
        mySize = myScores.size()
        y = 0
        while (y < mySize){
            leaguePlayed[x] = leaguePlayed[x] + 1
            HS = myScores[y].HomeScore.toInteger() 
            AS = myScores[y].AwayScore.toInteger()
            switch(item) {
                case myScores[y].HomeTeam.text() :
                    leagueGD[x] = leagueGD[x]  + (HS - AS )
                    leagueFor[x] += HS
                    leagueAgainst[x] += AS
                    if (HS > AS) {
                       leaguePTS[x] += 3 
                       leagueWon[x] += 1
                    } else
                        if (HS == AS) {
                            leaguePTS[x]   += 1 
                            leagueDrawn[x] += 1 
                        }   
                        else {
                            leagueLost[x] += 1 
                        }
                break;
                
                case myScores[y].AwayTeam.text() :
                    leagueGD[x] = leagueGD[x]  + (AS  - HS )
                    leagueFor[x] += AS
                    leagueAgainst[x] += HS
                    if (AS > HS) {
                       leaguePTS[x] += 3 
                       leagueWon[x] += 1
                    } else
                        if (HS == AS) {
                            leaguePTS[x]   += 1 
                            leagueDrawn[x] += 1 
                        }  
                        else {
                            leagueLost[x] += 1 
                        }
                break;  
                
            }
            y++
        }
        
        x++
        
    }
    
    x=0
    rootXml.League {
        for (item in leagueTeams) {
            Table{
                Team     leagueTeam[x]
                Played   leaguePlayed[x]
                Won      leagueWon[x]
                Drawn    leagueDrawn[x]
                Lost     leagueLost[x]
                For      leagueFor[x]
                Against  leagueAgainst[x]
                GoalDiff leagueGD[x]
                Points   leaguePTS[x]
            }
        x++    
        }
    }
    
    
    myTeams = []
    myTeams2 = properties.get("myTeams2")
    doTeams = properties.get("doTeams")
    mySize2 = Scores.size()
    scoresService = ""
    lastDate = ""
    x = 0
    while (x < mySize2) {
        if(doTeams == "N" || myTeams2.contains(Scores[x].HomeTeam.text()) || myTeams2.contains(Scores[x].AwayTeam.text()))  {  
            if (Scores[x].Date != lastDate){
                lastDate = Scores[x].Date.toString()
                myDate = lastDate.substring(8,10) + "/" + lastDate.substring(5,7) + "/" + lastDate.substring(0,4) 
                scoresService += "\n" + myDate.padLeft(32) + "\n"
            }
            scoresService += Scores[x].HomeTeam.text().replace("_"," ").padLeft(23) + Scores[x].HomeScore.text().padLeft(3) + " |"  + Scores[x].AwayScore.text().padLeft(2) + "  " + Scores[x].AwayTeam.text().replace("_"," ") + "\n"
        }    
        x++
    }
    
    
    message.setProperty("scoresService", scoresService)
    
    message.setBody(myXml.toString())

    return message;
}