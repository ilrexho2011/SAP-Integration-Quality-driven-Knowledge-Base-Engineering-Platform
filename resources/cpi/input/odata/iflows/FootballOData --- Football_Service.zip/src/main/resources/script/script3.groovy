import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.io.Reader

def Message processData(Message message) {

    // Stream the body to XmlSlurper (recommended)
    Reader reader = message.getBody(Reader)
    def myXML = new XmlSlurper(false, false).parse(reader)

    def myData = myXML.Scores.findAll {
        (it.HomeTeam?.text() ?: "").trim() == "Fail" || (it.AwayTeam?.text() ?: "").trim() == "Fail"
    }

    def Fails = []
    Fails = myData.collect { it }

    def mySize = Fails.size()
    def myMessage = ""
    def x = 0

    while (x < mySize) {
        myMessage += "\n" +
            (Fails[x].Date?.text() ?: "") + " " +
            (Fails[x].HomeTeam?.text() ?: "") + " " +
            (Fails[x].HomeScore?.text() ?: "") + " " +
            (Fails[x].AwayScore?.text() ?: "") + " " +
            (Fails[x].AwayTeam?.text() ?: "")
        x++
    }

    if (myMessage != "") {
        throw new Exception(
            "\nThere are TeamNames in the file that are not in the value mapping\n" +
            "See below for clues as to which they are\n" +
            myMessage + "\n"
        )
    }

    return message
}