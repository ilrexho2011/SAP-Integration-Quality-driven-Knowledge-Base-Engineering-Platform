<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method = "xml" indent="yes" omit-xml-declaration="yes" />	
    
    <xsl:template match = "node()|@*">
    	<xsl:copy>
    		<xsl:apply-templates select = "node()|@*" />
    	</xsl:copy>
    </xsl:template>

	<xsl:template match = "/League">
		<League>
			<xsl:apply-templates select = "/League/Table">
				<xsl:sort select = "Points" data-type = "number" order = "descending" />
				<xsl:sort select = "GoalDiff" data-type = "number" order = "descending" />
				<xsl:sort select = "For" data-type = "number" order = "descending" />
			</xsl:apply-templates>
		</League>
	</xsl:template>

 </xsl:stylesheet>
