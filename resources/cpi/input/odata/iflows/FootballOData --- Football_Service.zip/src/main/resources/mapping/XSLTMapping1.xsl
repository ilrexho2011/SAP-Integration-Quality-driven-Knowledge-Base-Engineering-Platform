<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method = "xml" indent="yes" omit-xml-declaration="yes" />	

	<xsl:template match = "/Scores" >
			<xsl:for-each-group select = "/Scores/Scores" group-by = "Date">
				<xsl:text>Date,</xsl:text>
		     	<xsl:value-of select="substring (Date ,9, 2 )"/>
		     	<xsl:text>/</xsl:text>
		     	<xsl:value-of select="substring (Date ,6, 2 )"/>
		     	<xsl:text>/</xsl:text>	
		     	<xsl:value-of select="substring (Date ,1, 4 )"/>
				<xsl:text>,,</xsl:text> 
				<xsl:text>&#xa;</xsl:text>
					<xsl:for-each select = "current-group()">
						<xsl:value-of select = "HomeTeam" /> <xsl:text>,</xsl:text>
						<xsl:value-of select = "HomeScore"/> <xsl:text>,</xsl:text>
						<xsl:value-of select = "AwayScore"/> <xsl:text>,</xsl:text>
						<xsl:value-of select = "AwayTeam"/>  <xsl:text>&#xa;</xsl:text>
					</xsl:for-each>
			</xsl:for-each-group>
	</xsl:template>


 </xsl:stylesheet>