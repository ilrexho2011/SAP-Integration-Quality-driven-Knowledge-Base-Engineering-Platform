import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def body = message.getBody(String)

    def doDelete = "N"
    String output = ""
    String myDate = ""

    body.eachLine { String line ->
        String myLine = line ?: ""

        // Siguri minimale: mos bëj substring nëse string është shumë i shkurtër
        if (myLine.startsWith("Delete")) {
            doDelete = "Y"
        }
        else if (myLine.startsWith("Date")) {
            // pritet si: Date,15/02/2025,,
            myLine = myLine.replace("Date,", "")
            myLine = myLine.replace(",,", "")
            myLine = myLine.trim()
            myDate = myLine
        }
        else {
            // Formato datën vetëm kur e kemi dhe është e vlefshme
            String newDate = ""

            if (myDate?.trim()) {
                // pranon dd/MM/yyyy ose d/M/yyyy
                def parts = myDate.trim().split("/")
                if (parts.size() == 3) {
                    String dd = parts[0].padLeft(2, '0')
                    String mm = parts[1].padLeft(2, '0')
                    String yyyy = parts[2]

                    // validim minimal
                    if (yyyy.size() == 4) {
                        newDate = "${yyyy}-${mm}-${dd}"
                    } else {
                        // fallback (nëse vjen format i çuditshëm)
                        newDate = myDate.trim()
                    }
                } else {
                    newDate = myDate.trim()
                }
            }

            // Normalizo emrat me underscore (siç e kishe)
            myLine = myLine.replaceAll(" ", "_")

            // Shkruaj vetëm nëse kemi datë dhe rresht jo bosh
            if (newDate && myLine.trim()) {
                output += "${newDate},${myLine}\n"
            }
        }
    }

    message.setHeader("doDelete", doDelete)
    message.setBody(output)
    return message
}