import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {
    def body = message.getBody(String);
    
    def Instruction = "N"
    def scoresBetween = 'N'
    def doLeague = "N"
    def doTeams  = "N"
    def myTeams = []
    
    myline = body.readLines()
    firstLine = myline[0]

    switch (firstLine) {
        
       case "League Table Teams" :
            doLeague = 'Y'
            Instruction = "GAS"  
            doTeams = "Y"
            mySize = myline.size()
            x=1
            while (x < mySize) {
                myTeams[x] = myline[x].replace(" ","_")
                x++
            }
            break;
            
       case "League Table" :
            doLeague = 'Y'
            Instruction = "GAS"   
            break;
            
       case "Get All Scores" :
            Instruction = "GAS"   
            break;
            
       case "Scores Between" :
            scoresBetween = 'Y'
            Instruction = "GAS"  
            break;
            
       case "Delete All Scores" :
            Instruction = "DAS"   
            break;
            
       case "League Table Between" :
            doLeague = 'Y'
            scoresBetween = 'Y'
            Instruction = "GAS"  
            break;
            
       case "League Table Between Teams" :
            doLeague = 'Y'
            scoresBetween = 'Y'
            Instruction = "GAS"  
            doTeams = "Y"
            mySize = myline.size()
            x=3
            while (x < mySize) {
                myTeams[x] = myline[x].replace(" ","_")
                x++
            }
            break;
            
       default :
            Instruction = "N"
    }
    
    message.setProperty("doTeams",doTeams)
    message.setProperty("myTeams2",myTeams)
    message.setProperty("Instruction", Instruction)
    message.setProperty("scoresBetween", scoresBetween)
    message.setProperty("doLeague", doLeague)
    
    return message;
}