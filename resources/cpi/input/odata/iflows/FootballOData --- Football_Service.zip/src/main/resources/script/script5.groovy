import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {
    def body = message.getBody(String);
    def properties = message.getProperties()
    
    def doDates = properties.get("scoresBetween")

    lowDate = '2001-01-01'
    highDate = '2099-12-31'    
    if (doDates == "Y")
      body.eachLine{ String line ->
        myLine = line
        if (myLine.substring(2,3) == "/"  && myLine.substring(5,6) == "/"  && lowDate == '2001-01-01' ) {
               lowDate = myLine.substring(6,10) + "-" + myLine.substring(3,5) + "-" + myLine.substring(0,2)
             }  else  
                if (myLine.substring(2,3) == "/"  && myLine.substring(5,6) == "/"  && highDate == '2099-12-31' ) {
                   highDate = myLine.substring(6,10) + "-" + myLine.substring(3,5) + "-" + myLine.substring(0,2)
                   }    
      
    }  
    
    if (lowDate > highDate) {
        temp = lowDate
        lowDate = highDate
        highDate = temp
    }
    
    
    message.setProperty("lowDate", lowDate)
    message.setProperty("highDate", highDate)
    return message;
}