import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    //Body
    def body = message.getBody();


    throw new Exception("There is a TeamName in the file that is bad")

    return message;
}