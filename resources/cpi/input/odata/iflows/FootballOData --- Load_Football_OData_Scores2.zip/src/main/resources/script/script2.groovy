import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {
    
    def body = message.getBody();
    
    def properties = message.getProperties();
    def Home = properties.get("Home")
    def Away = properties.get("Away")
    def myDate = properties.get("Date")
    myErr = "File with error contained " + Home + " v "  + Away + " on " + myDate + "\n\n\n" 
    message.setProperty("ErrorMessage2", myErr)
    

    return message;
}