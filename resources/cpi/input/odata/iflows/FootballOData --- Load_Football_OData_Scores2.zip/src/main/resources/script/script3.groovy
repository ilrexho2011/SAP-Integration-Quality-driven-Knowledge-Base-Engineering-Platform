import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {
    
    body = message.getBody(String)
    def properties = message.getProperties();
    def headers = message.getHeaders();
    def doDel = headers.get("doDelete")
    
    def gotIt = body.contains("Home")
    
    def toDo  = "POST"
    
    if (gotIt) {toDo = "PUT"}
    
    if (doDel == "Y") {
        if (toDo == "PUT") {toDo = "DELETE"}
      else {
        toDo = "FAIL" }
    }
 
    message.setProperty("toDo", toDo)
    
    savedBody = properties.get("savedBody")
    message.setBody(savedBody)

    return message;
}

