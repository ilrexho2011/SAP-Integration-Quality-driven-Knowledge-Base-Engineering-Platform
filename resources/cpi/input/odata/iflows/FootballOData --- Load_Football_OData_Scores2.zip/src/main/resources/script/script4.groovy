
import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    //Body
    def body = message.getBody();


    throw new Exception("\nThere was an attempt to delete a Score that is not in the database\n")


    return message;
}