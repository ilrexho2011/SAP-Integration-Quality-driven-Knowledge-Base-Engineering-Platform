<xsl:stylesheet version="2.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    
     <xsl:output omit-xml-declaration="yes" indent="yes"/>

<xsl:param name="Team_1" />
<xsl:param name="Team_2" />
<xsl:param name="Score_1" />
<xsl:param name="Score_2" />

     <xsl:template match="node()|@*">
             <xsl:copy>
                <xsl:apply-templates select="node()|@*" />
             </xsl:copy>
     </xsl:template>
     
     <xsl:template match="/Cricket_World_T20/Final/Score">
     
     <Score>
             <Home_Team>
                <xsl:value-of select="$Team_1"/>
             </Home_Team>
             <Home_Score>
                <xsl:value-of select="$Score_1"/>
             </Home_Score>
             <Away_Team>
                <xsl:value-of select="$Team_2"/>
             </Away_Team>
             <Away_Score>
                <xsl:value-of select="$Score_2"/>
             </Away_Score>
     </Score>
     
     </xsl:template>


</xsl:stylesheet>
