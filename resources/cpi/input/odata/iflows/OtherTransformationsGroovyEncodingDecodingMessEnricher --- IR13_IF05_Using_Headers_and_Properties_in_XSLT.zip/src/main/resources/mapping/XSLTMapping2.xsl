<xsl:stylesheet version="2.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
     xmlns:sci="http://sap.com/it/" exclude-result-prefixes="sci" >
     <xsl:output omit-xml-declaration="yes" indent="yes"/> 
     
     <xsl:param  name="exchange" /> 
     
     <xsl:template match="node()|@*">
         <xsl:copy>
            <xsl:apply-templates select="node()|@*" />
         </xsl:copy>
     </xsl:template>
     
     <xsl:variable name="HT" select="/Cricket_World_T20/Final/Score/Home_Team" />
     <xsl:variable name="AT" select="/Cricket_World_T20/Final/Score/Away_Team" />
     <xsl:variable name="Teams" select="concat($HT, ' and ', $AT)" />
     
     <xsl:template match="/">
         
         <xsl:apply-templates />
         
         <xsl:value-of select="sci:setHeader($exchange, 'Both_Teams', $Teams)"/>
         
         <xsl:value-of select="sci:setProperty($exchange, 'The Winner', 'India Won')"/>
         
     </xsl:template>
    
</xsl:stylesheet>