import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.util.XmlSlurper;
 
def Message processData(Message message) {
 
 body = message.getBody(String)
 myXML = new XmlSlurper().parseText(body)
 myData = myXML.Scores.findAll{it.HomeTeam == "Fail" || it.AwayTeam == "Fail"}
 
 Fails = []
 Fails = myData.collect{it}
 
 mySize = Fails.size()
 myMessage = ""
 x = 0
 
 while (x < mySize) {
 myMessage += "\n" + Fails[x].Date.text() + "   " + Fails[x].HomeTeam.text() + " " + Fails[x].HomeScore.text() + " " + Fails[x].AwayScore.text() + " " + Fails[x].AwayTeam.text()
 x++ 
 }
 
 if (myMessage != "") {
 throw new Exception("\nThere are TeamNames in the file that are not in the value mapping\nSee below for clues as to which they are\n" + myMessage + "\n")
 }
 
 return message;
}