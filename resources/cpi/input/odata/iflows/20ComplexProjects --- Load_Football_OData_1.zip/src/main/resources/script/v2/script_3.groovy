// This is Groovy Flowstep Version 2.x, running with Groovy runtime 4, Downgrade the script if older behaviour needed.

def processData(message) {

    String body = message.getBody(String) ?: ""
    def lines = body.split("\\r?\\n")

    String currentDate = ""
    StringBuilder output = new StringBuilder()

    lines.each { line ->

        def trimmed = line?.trim()
        if (!trimmed) return

        def parts = trimmed.split(",", -1)

        // Rreshti i datës
        if (parts[0].equalsIgnoreCase("Date")) {
            if (parts.size() > 1) {
                currentDate = parts[1].trim()
            }
            return
        }

        // Rreshti i ndeshjes
        if (parts.size() >= 4 && currentDate) {

            def home = parts[0].trim()
            def homeScore = parts[1].trim()
            def awayScore = parts[2].trim()
            def away = parts[3].trim()

            output.append("${currentDate},${home},${homeScore},${awayScore},${away}\n")
        }
    }

    message.setBody(output.toString())
    return message
}