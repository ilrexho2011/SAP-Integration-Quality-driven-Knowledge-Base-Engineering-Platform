// This is Groovy Flowstep Version 2.x, running with Groovy runtime 4, Downgrade the script if older behaviour needed.

import com.sap.it.script.v2.api.Message
import groovy.xml.XmlSlurper
import java.io.Reader

def Message processData(Message message) {

    Reader reader = message.getBody(Reader)   // streaming body
    def slurper = new XmlSlurper(false, false)
    def myXML = slurper.parse(reader)

    // Merr records: në varësi si del XML (Scores/Scores ose Scores/Score)
    def records = myXML.Scores
    if (records == null || records.size() == 0) {
        records = myXML.Score
    }

    // Fallback emrash fushash: HomeTeam/AwayTeam ose Home/Away
    def fails = records.findAll { node ->
        def home = (node.HomeTeam?.text() ?: node.Home?.text() ?: "")
        def away = (node.AwayTeam?.text() ?: node.Away?.text() ?: "")
        home == "Fail" || away == "Fail"
    }

    if (fails && fails.size() > 0) {
        def lines = fails.collect { node ->
            def date = node.Date?.text() ?: ""
            def home = (node.HomeTeam?.text() ?: node.Home?.text() ?: "")
            def away = (node.AwayTeam?.text() ?: node.Away?.text() ?: "")
            def hs = node.HomeScore?.text() ?: ""
            def as = node.AwayScore?.text() ?: ""
            "${date}   ${home} ${hs} ${as} ${away}"
        }.unique() // heq duplikimet

        throw new Exception(
            "\nThere are TeamNames in the file that are not in the value mapping" +
            "\nSee below for clues as to which they are\n" +
            lines.join("\n") + "\n"
        )
    }

    return message
}