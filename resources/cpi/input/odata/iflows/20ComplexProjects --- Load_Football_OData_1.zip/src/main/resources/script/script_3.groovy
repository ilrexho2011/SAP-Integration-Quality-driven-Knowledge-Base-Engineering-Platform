import com.sap.gateway.ip.core.customdev.util.Message;
 
def Message processData(Message message) {
 def body = message.getBody(String);
 
 def doDelete = "N"
 String Output = ""
 String myDate = ""
 body.eachLine{ String line ->
 myLine = line
 
 if (myLine.substring(0,6) == "Delete") {
 doDelete = "Y" 
 } 
 else {
 if (myLine.substring(0,4) == "Date") {
 myLine = myLine.replace("Date,","")
 myLine = myLine.replace(",,","")
 myDate =  myLine
 }
 else {
 newDate = myDate.substring(6, 10) + "-" + myDate.substring(3, 5) + "-" + myDate.substring(0, 2)
 myLine = myLine.replaceAll(" ","_")
 Output = Output + newDate + "," + myLine + "\n"
 }
 } 
 
 } 
 
 message.setHeader("doDelete", doDelete)
 message.setBody(Output)
 return message;
}
