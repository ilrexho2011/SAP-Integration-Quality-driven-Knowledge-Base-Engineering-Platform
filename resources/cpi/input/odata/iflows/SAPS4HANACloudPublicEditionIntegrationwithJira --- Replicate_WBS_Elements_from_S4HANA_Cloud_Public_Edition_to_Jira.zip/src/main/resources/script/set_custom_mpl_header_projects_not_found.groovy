import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        def deltaTimestamp = message.getProperty("current_execution_last_processed_project_updated_at_timestamp") as String
        def customQueryFilter = message.getProperty("custom_query_filter") as String
        
        def fullFilterQuery = "LastChangeDateTime ge datetimeoffset'$deltaTimestamp' and substringof(ProjectDescription, 'JK:') $customQueryFilter"
        messageLog.addCustomHeaderProperty("Projects not found matching filter", fullFilterQuery)
    }
    return message
}