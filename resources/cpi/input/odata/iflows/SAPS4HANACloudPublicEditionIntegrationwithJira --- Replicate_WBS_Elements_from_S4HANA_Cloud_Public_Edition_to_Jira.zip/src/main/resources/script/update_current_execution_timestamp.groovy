import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

import java.time.ZonedDateTime
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

def Message processData(Message message) {
    def currentExecutionLastProcessedProjectUpdatedAtTimestamp = message.getProperty("current_execution_last_processed_project_updated_at_timestamp")

    def body = message.getBody(java.io.Reader)
    if (body == null) {
        return message
    }

    def xml = new XmlSlurper().parse(body)
    if (xml == null || xml.project == null || xml.project.size() == 0) {
        return message
    }

    ZonedDateTime latestProcessedProjectUpdatedAt = null

    xml.project.each { project ->
        def updatedAtString = project.updatedAt.text()
        if (updatedAtString != null && !updatedAtString.trim().isEmpty()) {
            try {
                ZonedDateTime currentIteratedProjectUpdatedAt = parseFlexibleZonedDateTime(updatedAtString)
                
                if (latestProcessedProjectUpdatedAt == null || currentIteratedProjectUpdatedAt.isAfter(latestProcessedProjectUpdatedAt)) {
                    latestProcessedProjectUpdatedAt = currentIteratedProjectUpdatedAt
                }
            } catch (DateTimeParseException e) {
                messageLog?.addAttachment("InvalidDate", "Invalid date format in project.updatedAt: ${updatedAtString}")
            }
        }
    }

    if (latestProcessedProjectUpdatedAt == null) {
        latestProcessedProjectUpdatedAt = ZonedDateTime.parse("1970-01-01T00:00:00Z")
    }

    if (currentExecutionLastProcessedProjectUpdatedAtTimestamp == null || currentExecutionLastProcessedProjectUpdatedAtTimestamp.toString().trim().isEmpty()) {
        message.setProperty("current_execution_last_processed_project_updated_at_timestamp", formatZonedDateTime(latestProcessedProjectUpdatedAt))
    } else {
        try {
            ZonedDateTime currentExecZdt = parseFlexibleZonedDateTime(currentExecutionLastProcessedProjectUpdatedAtTimestamp.toString())

            if (latestProcessedProjectUpdatedAt.isAfter(currentExecZdt)) {
                message.setProperty("current_execution_last_processed_project_updated_at_timestamp", formatZonedDateTime(latestProcessedProjectUpdatedAt))
            }
        } catch (DateTimeParseException e) {
            messageLog?.addAttachment("InvalidCurrentExecutionDate", "Invalid timestamp property: ${currentExecutionLastProcessedProjectUpdatedAtTimestamp}. Replacing with latest.")
            message.setProperty("current_execution_last_processed_project_updated_at_timestamp", formatZonedDateTime(latestProcessedProjectUpdatedAt))
        }
    }

    return message
}

private ZonedDateTime parseFlexibleZonedDateTime(String timestamp) {
    if (timestamp == null) return null
    
    def ts = timestamp.trim()
    
    if (ts.endsWith("Z") || ts.contains("+") || ts.lastIndexOf("-") > 7) { 
         return ZonedDateTime.parse(ts, DateTimeFormatter.ISO_ZONED_DATE_TIME)
    } else {
         return LocalDateTime.parse(ts).atZone(ZoneId.of("UTC"))
    }
}

private String formatZonedDateTime(ZonedDateTime zonedDateTime) {
    if (zonedDateTime == null) return null
    return zonedDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME)
}