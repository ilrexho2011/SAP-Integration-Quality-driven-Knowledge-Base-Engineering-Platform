import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def slurper = new JsonSlurper()

    def projectName = message.getProperty("project_name")
    def body = message.getBody(java.io.Reader)

    def jsonPayload = slurper.parse(body)

    def contextForProject = jsonPayload.values.find { it.name.startsWith(projectName)}

    if (contextForProject) {
        message.setProperty("context_id", contextForProject.id)
        message.setProperty("is_last_context_page", true)

        return message
    }

    message.setProperty("is_last_context_page", jsonPayload.isLast)
    message.setProperty("context_start_at", (int) jsonPayload.startAt + (int) jsonPayload.maxResults)
    return message
}