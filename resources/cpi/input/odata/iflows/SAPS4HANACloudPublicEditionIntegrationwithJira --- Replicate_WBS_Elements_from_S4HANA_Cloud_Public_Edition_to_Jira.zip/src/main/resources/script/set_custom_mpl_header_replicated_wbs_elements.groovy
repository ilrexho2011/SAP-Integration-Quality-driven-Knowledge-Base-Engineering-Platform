import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        def projectName = message.getProperty("project_name") as String;
        def wbsRaw = message.getProperty("wbs_elements_names")?.toString() ?: ""

        if (projectName && wbsRaw) {
            def cleanString = wbsRaw.replaceAll(/[\[\]\"]/, "")
            def elements = cleanString.split(",")

            elements.each { val ->
                def currentWBS = val.trim()
                if (currentWBS) {
                    messageLog.addCustomHeaderProperty("Replicated WBS Element", currentWBS);
                }
            }
        }
    }
    return message;
}