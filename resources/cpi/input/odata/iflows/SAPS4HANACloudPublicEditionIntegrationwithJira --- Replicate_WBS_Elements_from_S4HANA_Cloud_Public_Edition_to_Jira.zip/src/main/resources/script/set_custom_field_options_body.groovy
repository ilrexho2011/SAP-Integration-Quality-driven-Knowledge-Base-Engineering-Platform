import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def existingOptionsResponse = message.getProperty("existing_field_options") as String ?: "{\"values\":[]}"
    def jsonSlurper = new JsonSlurper()
    def existingOptionsList = jsonSlurper.parseText(existingOptionsResponse)?.values ?: []

    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)

    def allProjectElements = xml.A_EnterpriseProjectType.to_EnterpriseProjectElement.A_EnterpriseProjectElementType
    
    def newOptions = []
    def finalPutList = []
    boolean updateDetected = false

    allProjectElements.each { element ->
        def projectID = element.ProjectElement.text().trim()
        def description = element.ProjectElementDescription.text().trim()
        def billingFlag = element.WBSElementIsBillingElement.text().trim()
        
        def combinedValue = "${projectID} | ${description}".trim()

        def descFilter = !description.contains("JK:")
        def billingFilter = (billingFlag == 'false')
        def passesFilters = (allProjectElements.size() == 1) ? true : (descFilter && billingFilter)

        if (passesFilters) {
            def existingItem = existingOptionsList.find { 
                def val = it.value?.toString() ?: ""
                val.startsWith(projectID + " |") || val == projectID 
            }
            
            if (existingItem) {
                if (existingItem.value != combinedValue) {
                    updateDetected = true
                }
                
                finalPutList << [
                    disabled: false, 
                    id: existingItem.id, 
                    value: combinedValue
                ]
            } else {
                newOptions << [disabled: false, value: combinedValue]
            }
        }
    }

    existingOptionsList.each { existing ->
        def existingFullValue = existing.value?.toString() ?: ""
        def existingIDPrefix = existingFullValue.split(" \\| ")[0]
        
        def alreadyProcessed = finalPutList.any { 
            def val = it.value?.toString() ?: ""
            val.startsWith(existingIDPrefix + " |") || val == existingIDPrefix 
        }
        
        if (!alreadyProcessed) {
            finalPutList << [
                disabled: existing.disabled ?: false,
                id: existing.id,
                value: existing.value
            ]
        }
    }

    def putResult = [options: finalPutList]
    def postResult = [options: newOptions]

    message.setProperty("has_updates", updateDetected)
    message.setProperty("put_payload", JsonOutput.toJson(putResult))
    message.setProperty("is_empty_options", newOptions.isEmpty())
    message.setProperty("post_payload", JsonOutput.toJson(postResult))
    
    message.setBody(JsonOutput.toJson(putResult))
    
    return message
}