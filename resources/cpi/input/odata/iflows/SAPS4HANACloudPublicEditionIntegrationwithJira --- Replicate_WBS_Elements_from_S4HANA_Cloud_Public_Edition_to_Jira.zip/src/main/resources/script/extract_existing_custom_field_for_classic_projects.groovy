import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def CUSTOM_FIELD_NAME = "WBS Elements"
    
    def jiraFieldsRaw = message.getProperty("jira_fields_body") as String
    def jiraFields = new JsonSlurper().parseText(jiraFieldsRaw)

    def existingField = jiraFields.find { it -> it.name == CUSTOM_FIELD_NAME }
    
    if (existingField) {
        message.setProperty("custom_field_id", existingField.id)
    }

    message.setProperty("has_custom_field", (boolean) existingField)

    return message
}