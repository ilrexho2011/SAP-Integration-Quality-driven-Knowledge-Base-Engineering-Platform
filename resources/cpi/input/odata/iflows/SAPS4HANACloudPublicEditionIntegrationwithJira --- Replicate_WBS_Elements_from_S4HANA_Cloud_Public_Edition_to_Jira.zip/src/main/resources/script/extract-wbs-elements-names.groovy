import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def body = message.getBody(java.io.Reader) ?: ""

    def json = body ? new JsonSlurper().parse(body) : [:]
    def options = (json?.options instanceof List) ? json.options : []

    List<String> values = options
        .collect { it?.value }
        .findAll { it != null } as List<String>

    message.setProperty("wbs_elements_names", JsonOutput.toJson(values).replace('","', '", "'))


    return message
}
