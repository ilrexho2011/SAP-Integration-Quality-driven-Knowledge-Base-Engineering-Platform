import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def json = new JsonSlurper().parse(message.getBody(java.io.Reader))
    def customFieldId = message.getProperty("custom_field_id")
    
    def includesField = json.any { it.id == customFieldId }
    message.setProperty("includes_field", includesField)
    return message
}