import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        def project = message.getProperty("project_name") as String;
        messageLog.addCustomHeaderProperty("Field needs manual setup for Project", project);
    }

    return message;
}