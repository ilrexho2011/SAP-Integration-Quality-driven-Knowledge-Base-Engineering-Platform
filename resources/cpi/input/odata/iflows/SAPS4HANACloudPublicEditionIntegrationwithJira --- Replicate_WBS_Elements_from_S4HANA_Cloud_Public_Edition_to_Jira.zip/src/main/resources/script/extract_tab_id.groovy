import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def json = new JsonSlurper().parse(message.getBody(java.io.Reader))

    def tabId = json[0].id

    message.setProperty("tab_id", tabId)

    return message
}