import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

Message processData(Message message) {

    def json = new JsonSlurper().parse(message.getBody(java.io.Reader))

    def runName = (json.run_name ?: "").toString().trim()
    def runStatus = (json.run_status ?: json.status ?: "").toString().trim().toLowerCase()

    if (!runName) {
        throw new IllegalStateException("Missing run_name in ProcessDirect payload")
    }

    message.setProperty("pd_run_name", runName)
    message.setProperty("pd_run_status", runStatus)
    message.setProperty("pd_payload_raw", JsonOutput.toJson(json))

    message.setHeader("RunName", runName)
    message.setHeader("RunStatus", runStatus)

    // E rikthen body-n si JSON valid për hapat pasues
    message.setBody(JsonOutput.toJson(json))

    return message
}