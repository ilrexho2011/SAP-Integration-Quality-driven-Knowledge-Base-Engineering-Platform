import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.xml.XmlUtil

def Message processData(Message message) {
    def slurper = new XmlSlurper()

    def body = message.getBody(java.io.Reader)
    def multiMapBody = slurper.parse(body)
    
    def outputDataRaw = message.getProperty("output_data")
    def outputData = slurper.parseText(outputDataRaw) 

    def allBPUUIDs = multiMapBody.Message1.A_BusinessPartners.A_BusinessPartner.A_BusinessPartnerType.BusinessPartnerUUID*.text()
 
    def uniqueUuidsToAdd = allBPUUIDs.unique()

    def teamMemberListNode = outputData.A_EnterpriseProjectType.to_EntProjTeamMember

    def existingUUIDs = teamMemberListNode.A_EnterpriseProjectTeamMemberType.BusinessPartnerUUID*.text().toSet()

    uniqueUuidsToAdd.each { bpUUID ->
        if (bpUUID && !existingUUIDs.contains(bpUUID)) {
            
            teamMemberListNode.appendNode {
                A_EnterpriseProjectTeamMemberType {
                    BusinessPartnerUUID(bpUUID)
                }
            }
        }
    }

    def newBodyString = XmlUtil.serialize(outputData)
    
    message.setBody(newBodyString)
    
    return message
}