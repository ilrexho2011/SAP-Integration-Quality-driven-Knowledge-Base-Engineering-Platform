import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message)
    
    if (messageLog != null) {
        def projectName = message.getProperty("project_name") as String
        def wbsElement = message.getProperty("wbs_element_name") as String
        def headerValue = ["Project": " " + projectName + ", " + "WBS Element: " + wbsElement].toString()
        if (projectName != null && !projectName.isEmpty()) {
            messageLog.addCustomHeaderProperty("Team Member Not Confirmed in ", headerValue)
        }
    }
    return message
}