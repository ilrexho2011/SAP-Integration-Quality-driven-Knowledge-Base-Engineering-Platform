<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" indent="yes"/>
    <xsl:param name="CurrentRunTime"/>
    <xsl:template match="/">
        <html>
            <head>
                <style>
                    body {
                        font-family: '72', Verdana, sans-serif;
                        background-color: #f5f6f7;
                        margin: 0;
                        padding: 0;
                        font-size: 11px;
                    }
                    .container {
                        background-color: #ffffff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
                        max-width: 900px;
                        margin: 20px auto;
                        border: 1px solid #e1e4e8;
                    }
                    .header {
                        background-color: #475E75;
                        color: #F5F6F7;
                        padding: 10px;
                        text-align: center;
                        font-size: 18px;
                        font-weight: bold;
                        border-radius: 6px 6px 0 0;
                    }
                    .content {
                        padding: 15px;
                        font-size: 11px;
                        color: #1D2D3E;
                    }
                    .details {
                        background-color: #F5F6F7;
                        padding: 12px;
                        border-radius: 6px;
                        font-size: 10px;
                        margin-bottom: 20px;
                        border: 1px solid #e1e4e8;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        table-layout: auto;
                        font-size: 11px;
                    }
                    th,
                    td {
                        border: 1px solid #e1e4e8;
                        padding: 8px;
                        text-align: left;
                        font-size: 11px;
                        vertical-align: top;
                        word-wrap: break-word;
                    }
                    th {
                        background-color: #475E75;
                        color: white;
                        font-weight: bold;
                    }
                    tr:nth-child(even) {
                        background-color: #F5F6F7;
                    }
                    /* Ensure Message ID and Correlation ID do not wrap */
                    .nowrap {
                        white-space: nowrap;
                        overflow: hidden;
                        max-width: 250px;
                    }
                    /* Limit error message width and allow wrapping */
                    .error-message {
                        max-width: 400px;
                        word-wrap: break-word;
                        white-space: normal;
                    }
                    .monitor-link {
                        color: #006b8f;
                        text-decoration: none;
                        font-weight: bold;
                        font-size: 11px;
                    }
                    .large-text {
                        font-size: 13px;
                        color: #1D2D3E;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">SAP CPI Error Notification</div>
                    <div class="content">
                        <div class="details">
                            <p class= "large-text">
                                <strong>iFlow Name: </strong>
                                <xsl:value-of select="/MessageProcessingLog/Record/Error[1]/iFlowName"/></p>
                            <p class="large-text"><strong>Time Interval (UTC):  </strong><xsl:value-of select="substring(/MessageProcessingLog/Record/Error/DateAndTime, 1, 10)"/>:<xsl:value-of select="substring(/MessageProcessingLog/Record/Error/DateAndTime, 12, 8)"/> To <xsl:value-of select="substring($CurrentRunTime, 1, 10)"/>:<xsl:value-of select="substring($CurrentRunTime, 12, 8)"/></p>
                            <p class="large-text">
                                <strong>Total Errors: </strong>
                                <xsl:value-of select="count(/MessageProcessingLog/Record/Error)"/></p>
                        </div>
                        
                        <p class="large-text">
	                        <strong>Error Report: </strong>
                        </p>
                  
                        <table>
                            <tr>
                                <th style="width: 15%;">Message ID</th>
                                <th style="width: 15%;">Correlation ID</th>
                                <th style="width: 45%;">Error Message</th>
                                <th style="width: 15%;">Date &amp; Time (UTC)</th>
                                <th style="width: 10%;">Monitor</th>
                            </tr>
                            <xsl:for-each select="/MessageProcessingLog/Record/Error">
                                <tr>
                                    <td class="nowrap"><xsl:value-of select="MessageID"/></td>
                                    <td class="nowrap"><xsl:value-of select="CorrelationID"/></td>
                                    <td class="error-message"><xsl:value-of select="ExceptionMessage"/></td>
                                    <td class="nowrap"><xsl:value-of select="substring(DateAndTime, 1, 10)"/> &amp; <xsl:value-of select="substring(DateAndTime, 12, 8)"/></td>
                                    <td>
                                        <a class="monitor-link">
                                            <xsl:attribute name="href"><xsl:value-of select="iFlowLink"/></xsl:attribute>
                                            Link
                                        </a>
                                    </td>
                                </tr>
                            </xsl:for-each>
                        </table>
                    </div>
                    <div class="footer">
                        <p style="text-align: center; font-size: 10px; font-style: italic; color: #1D2D3E;">***This is an automated email, please do not reply***</p>
                    </div>
                </div>
            </body>
        </html>
    </xsl:template>
</xsl:stylesheet>