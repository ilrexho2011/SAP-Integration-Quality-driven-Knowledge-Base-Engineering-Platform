<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0" xmlns:atom="http://www.w3.org/2005/Atom"
    xmlns:m="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata"
    xmlns:d="http://schemas.microsoft.com/ado/2007/08/dataservices"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:multimap="http://sap.com/xi/XI/SplitAndMerge"
    exclude-result-prefixes="atom m d xsl multimap">
    
    <xsl:strip-space elements="*"/>
    <xsl:output indent="yes" omit-xml-declaration="no"
        media-type="application/xml" encoding="UTF-8" />
    
    <xsl:template match="multimap:Message1">            
            <!-- Creating Inidividual Error Message Groups by grouping on same interface ID --> 
        <MessageProcessingLog> 
             <xsl:for-each-group select="MessageProcessingLogs"
                 group-by="MessageProcessingLog/IntegrationFlowName">               
                    <Record>
                        <xsl:for-each select="//MessageProcessingLogs/MessageProcessingLog[IntegrationFlowName = current-grouping-key()]">
                        <Error>
                        <iFlowName>
				            <xsl:value-of select="IntegrationArtifact/Name"/>
			            </iFlowName>
			            <DateAndTime>
				            <xsl:value-of select="LogEnd"/>
			            </DateAndTime>
			            <iFlowLink>
				            <xsl:value-of select="AlternateWebLink"/>
			            </iFlowLink>
			            <ExceptionMessage>
                            <xsl:value-of select="../ErrorText" />
                        </ExceptionMessage>
		            	<CorrelationID>
                            <xsl:value-of select="CorrelationId" />
                        </CorrelationID> 
                        <MessageID>
                            <xsl:value-of select="MessageGuid" />
                        </MessageID>
                        <ApplicationMessageId>
                            <xsl:value-of select="ApplicationMessageId" />
                        </ApplicationMessageId>  
                        <CustomHeaders>
                            <xsl:value-of select="../CustomHeaders" />
                        </CustomHeaders>
                    </Error>                       
                    </xsl:for-each> 
                    </Record>
                  
              </xsl:for-each-group> 
         </MessageProcessingLog>  
    </xsl:template>
    
    
    <!-- Default templates to do nothing -->
    <!-- ########## -->
    <xsl:template match="text()" priority="-100"/>
    
</xsl:stylesheet>