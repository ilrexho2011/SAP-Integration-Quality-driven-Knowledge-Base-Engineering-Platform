import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonBuilder;
import groovy.json.JsonSlurper;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String) as String;
      def slurped = new JsonSlurper().parseText(body);
      def Sprint =  slurped.fields.customfield_10020;
      def builder = new JsonBuilder(slurped);
      builder.content.fields.customfield_10020 = Integer.valueOf(Sprint); 
      message.setBody(builder.toString());    
   
       return message;
}