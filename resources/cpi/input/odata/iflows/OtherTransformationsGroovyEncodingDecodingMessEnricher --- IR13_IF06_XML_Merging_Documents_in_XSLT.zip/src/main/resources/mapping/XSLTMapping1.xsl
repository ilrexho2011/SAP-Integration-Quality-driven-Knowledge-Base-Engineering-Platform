<xsl:stylesheet version="2.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output omit-xml-declaration="yes" indent="yes"/>
    
    <xsl:param name="myXML" />
    
        <xsl:variable name="myDoc" select="parse-xml($myXML)" />
             <xsl:template match="node()|@*">
             <xsl:copy>
             <xsl:apply-templates select="node()|@*" />
             </xsl:copy>
             
         </xsl:template>
            <xsl:template match="/">
                
                <NewRoot>
                     <xsl:copy-of select="." />
                     <xsl:copy-of select="$myDoc/Awards/Winners[@Year = '2024']" />
                </NewRoot>
                
            </xsl:template>
    
</xsl:stylesheet>
