import com.sap.gateway.ip.core.customdev.util.Message
import java.time.ZonedDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

Message processData(Message message) {
    def now = ZonedDateTime.now(ZoneId.of("Europe/Tirane"))
    def ts = now.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
    def shortId = UUID.randomUUID().toString().substring(0, 8)
    message.setProperty("run_name", "run_${ts}_${shortId}")
    return message
}
