<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
 <xsl:output omit-xml-declaration="yes" indent="yes"/>
 <xsl:output method="xml" indent="yes"/> 
 
    <xsl:param name="myName" /> 
    
    
    <xsl:template match = "node()|@*">
         <xsl:copy>
            <xsl:apply-templates select = "node()|@*" />
         </xsl:copy>
    </xsl:template>
    
    
     <xsl:template match = "/myOrder" >
        <myOrder>
            <xsl:apply-templates/>
        </myOrder>
    </xsl:template>
    
        
    <xsl:template match = "/myOrder/Name" >
        
        <Name><xsl:value-of select="$myName"/></Name>
    
    </xsl:template>



</xsl:stylesheet>