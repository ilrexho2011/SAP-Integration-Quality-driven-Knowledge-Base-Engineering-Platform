import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {
    def body = message.getBody(String)
    if (!body) throw new IllegalStateException("Empty response body")
    def json = new JsonSlurper().parseText(body)
    message.setProperty("run_status", (json.status ?: "unknown").toString())
    message.setProperty("run_name", (json.run_name ?: "").toString())
    message.setProperty("run_progress", (json.progress ?: "").toString())
    message.setProperty("run_payload_raw", body)
    return message
}
