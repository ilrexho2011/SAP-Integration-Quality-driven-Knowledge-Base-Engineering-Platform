import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {

    def baseUrl = message.getProperty("PLATFORM_BASE_URL")
    def runName = message.getProperty("run_name")

    if (!baseUrl) {
        throw new IllegalStateException("Missing PLATFORM_BASE_URL")
    }

    if (!runName) {
        throw new IllegalStateException("Missing run_name")
    }

    baseUrl = baseUrl.toString().trim()
    runName = runName.toString().trim()

    // Heq slash në fund, nëse ekziston
    if (baseUrl.endsWith("/")) {
        baseUrl = baseUrl.substring(0, baseUrl.length() - 1)
    }

    def statusUrl = "${baseUrl}/migration/run/${runName}"

    message.setHeader("CamelHttpUri", statusUrl)
    message.setHeader("CamelHttpMethod", "GET")
    message.setHeader("Accept", "application/json")

    return message
}
