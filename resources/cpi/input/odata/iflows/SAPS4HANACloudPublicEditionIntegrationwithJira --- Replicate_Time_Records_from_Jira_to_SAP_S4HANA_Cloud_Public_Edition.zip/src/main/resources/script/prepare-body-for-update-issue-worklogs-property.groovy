import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.util.XmlSlurper

def Message processData(Message message) {

    def issueWorklogsProperty = message.getProperty("issue_worklogs_custom_property") ?: "[]"
    def issueWorklogsPropertyParsed = new JsonSlurper().parseText(issueWorklogsProperty)

    List<Map> issueWorklogsPropertyList
    if (issueWorklogsPropertyParsed instanceof Map && issueWorklogsPropertyParsed.containsKey("value") && (issueWorklogsPropertyParsed.value instanceof List)) {
        issueWorklogsPropertyList = (List<Map>) issueWorklogsPropertyParsed.value
    } else if (issueWorklogsPropertyParsed instanceof List) {
        issueWorklogsPropertyList = (List<Map>) issueWorklogsPropertyParsed
    } else {
        issueWorklogsPropertyList = []
    }

    def newXml = message.getBody(java.io.Reader) ?: "[]"

    def root = new XmlSlurper().parse(newXml)

    List<Map> newList = root.worklog.collect { wl ->
        String worklogId   = (wl.worklog_id.text() ?: "")
        String companyCode = (wl.company_code.text() ?: "")
        String workerId    = (wl.worker_id.text() ?: "")

        String timesheetRecordText = (wl.timesheetRecord.text() ?: "[]")
        def s4TimesheetRecords = new JsonSlurper().parseText(timesheetRecordText)

        return [
            worklog_id          : worklogId,
            s4_timesheet_records: s4TimesheetRecords,
            company_code        : companyCode,
            worker_id           : workerId
        ]
    } as List<Map>

    Map<String, Map> mergedById = new LinkedHashMap<>()

    issueWorklogsPropertyList.each { Map item ->
        def id = (item?.worklog_id ?: "").toString()
        if (id) mergedById[id] = item
    }

    newList.each { Map item ->
        def id = (item?.worklog_id ?: "").toString()
        if (id) {
            mergedById[id] = item
        }
    }

    List<Map> merged = mergedById.values().toList()

    message.setBody(JsonOutput.toJson(merged))
    message.setHeader("Content-Type", "application/json")

    return message
}
