import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def json = new JsonSlurper().parse(body)

    message.setProperty("is_next_gen", json.style == "next-gen")
    message.setProperty("jira_project_id", json.id)

    return message
}