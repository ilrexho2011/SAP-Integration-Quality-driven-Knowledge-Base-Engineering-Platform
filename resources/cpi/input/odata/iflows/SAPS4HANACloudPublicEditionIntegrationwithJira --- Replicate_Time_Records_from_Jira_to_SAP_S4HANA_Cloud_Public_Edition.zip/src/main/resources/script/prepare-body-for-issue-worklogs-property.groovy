import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def worklogs_for_issue = message.getProperty("worklogs_for_issue")

    def root = new XmlSlurper().parseText(worklogs_for_issue)

    def result = root.worklog.collect { wl ->
        String worklogId   = (wl.worklog_id.text() ?: "").trim()
        String companyCode = (wl.company_code.text() ?: "").trim()
        String workerId    = (wl.worker_id.text() ?: "").trim()

        String timesheetRecordText = (wl.timesheetRecord.text() ?: "[]").trim()
        def s4TimesheetRecords = new JsonSlurper().parseText(timesheetRecordText)

        return [
            worklog_id          : worklogId,
            s4_timesheet_records: s4TimesheetRecords,
            company_code        : companyCode,
            worker_id           : workerId
        ]
    }

    message.setBody(JsonOutput.toJson(result))
    message.setHeader("Content-Type", "application/json")

    return message
}
