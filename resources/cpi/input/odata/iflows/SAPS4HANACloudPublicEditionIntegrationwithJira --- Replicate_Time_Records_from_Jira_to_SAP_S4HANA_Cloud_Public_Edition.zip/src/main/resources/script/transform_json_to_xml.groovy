import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def data = new JsonSlurper().parse(body)

    def builder = new StreamingMarkupBuilder()

    def newXml = builder.bind { mkp ->
        mkp.Issues {

            data.issues.each { issue ->
                def fields = issue.fields

                def customFieldEntry = fields.find { entry ->
                    entry.key.startsWith("customfield_") &&
                            entry.value instanceof Map &&
                            entry.value.containsKey("value")
                }

                def updated = issue.fields.updated
                def worklogs = issue.properties?.worklogs ?: []
                def timespent = issue.fields.timespent

                if ((timespent == 0 || timespent == null) && worklogs.isEmpty()) {
                    return
                }

                def customValue = customFieldEntry ? customFieldEntry?.value?.value.split("\\|")[0].trim() : null
                

                Issue {
                    IssueKey(issue.key)
                    WBSElement(customValue)
                    UpdatedAt(updated)
                    Worklogs(JsonOutput.toJson(worklogs))
                }
            }
        }
    }

    message.setBody(XmlUtil.serialize(newXml))

    return message
}