import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {

        def projectName = message.getProperty("project_name") as String
        def worklogId = message.getProperty("worklog_id") as String
        def headerValue = "Project Name: ${projectName}, Worklog ID: ${worklogId}"
        if (worklogId != null && !worklogId.isEmpty() && projectName != null && !projectName.isEmpty()) {
            messageLog.addCustomHeaderProperty("Successfully Deleted Worklog", headerValue)
        }
    }
    return message
}