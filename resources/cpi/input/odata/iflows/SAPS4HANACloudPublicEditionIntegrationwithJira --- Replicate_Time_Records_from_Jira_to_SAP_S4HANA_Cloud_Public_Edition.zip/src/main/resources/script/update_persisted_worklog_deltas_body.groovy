import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil
import groovy.util.XmlSlurper

def Message processData(Message message) {

    def body = message.getBody(String)

    def root = new XmlSlurper(false, false).parseText(body)

    def issuesNode = root.issues

    def issuesXml = XmlUtil.serialize(issuesNode)

    issuesXml = issuesXml.replaceFirst(/<\?xml[^>]*\?>\s*/, "")

    message.setBody(issuesXml)

    return message
}
