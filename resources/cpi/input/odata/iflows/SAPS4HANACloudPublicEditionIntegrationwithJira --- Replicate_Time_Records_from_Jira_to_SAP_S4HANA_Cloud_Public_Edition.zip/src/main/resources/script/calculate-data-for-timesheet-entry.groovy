import com.sap.gateway.ip.core.customdev.util.Message
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.math.BigDecimal
import java.math.RoundingMode

def Message processData(Message message) {

    // Read total time from Jira (seconds) 
    def rawValue = message.getProperty("time_spent_seconds")
    long timeSpentSeconds = 0L

    if (rawValue != null && rawValue.toString().trim()) {
        try {
            timeSpentSeconds = rawValue.toString().toLong()
        } catch (Exception e) {
            timeSpentSeconds = 0L
        }
    }

    // Read working hours per day (configurable, default 8)
    def rawWorkingHours = message.getProperty("working_hours_per_day")
    long workingHoursPerDay = 8L // default

    if (rawWorkingHours != null && rawWorkingHours.toString().trim()) {
        long parsed = rawWorkingHours.toString().toLong()
        if (parsed > 0L) {
            workingHoursPerDay = parsed
            }
    }

    message.setProperty("working_hours_per_day", workingHoursPerDay)

    // Split into full business days + leftover hours
    long secondsPerBusinessDay = workingHoursPerDay * 60L * 60L

    long fullBusinessDays = 0L
    BigDecimal remainingHours = BigDecimal.ZERO

    if (timeSpentSeconds > 0L && secondsPerBusinessDay > 0L) {
        fullBusinessDays = timeSpentSeconds / secondsPerBusinessDay
        long remainingSeconds = timeSpentSeconds % secondsPerBusinessDay

        remainingHours = new BigDecimal(remainingSeconds)
                .divide(new BigDecimal(3600), 2, RoundingMode.HALF_UP)
    }

    def startedRaw = message.getProperty("started")

    String startDateIso
    if (startedRaw != null && startedRaw.toString().trim()) {
        String tmp = startedRaw.toString().trim()
        if (tmp.length() >= 10) {
            startDateIso = tmp.substring(0, 10)
        } else {
            startDateIso = tmp
        }
    } 
    
    LocalDate startDate = LocalDate.parse(
        startDateIso,
        DateTimeFormatter.ISO_LOCAL_DATE
    )

    // Store state for the loop
    message.setProperty("business_days_remaining", fullBusinessDays)
    message.setProperty("remaining_hours", remainingHours.toPlainString())
    message.setProperty("current_date", startDate.toString())

    boolean hasMoreTime = (fullBusinessDays > 0L || remainingHours.compareTo(BigDecimal.ZERO) > 0)
    message.setProperty("has_more_time", hasMoreTime)

    message.setProperty("total_time_spent_seconds", timeSpentSeconds)

    return message
}
