import com.sap.gateway.ip.core.customdev.util.Message
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Set
import java.util.HashSet

def Message processData(Message message) {

    long days = 0L
    def rawDays = message.getProperty("business_days_remaining")
    if (rawDays != null && rawDays.toString().trim()) {
        try {
            days = rawDays.toString().toLong()
        } catch (Exception e) {
            days = 0L
        }
    }

    BigDecimal hoursRemaining = BigDecimal.ZERO
    def rawHours = message.getProperty("remaining_hours")
    if (rawHours != null && rawHours.toString().trim()) {
        try {
            hoursRemaining = new BigDecimal(rawHours.toString())
        } catch (Exception e) {
            hoursRemaining = BigDecimal.ZERO
        }
    }

    String currentDateStr = (message.getProperty("current_date") ?: "").toString()
    if (!currentDateStr) {
        currentDateStr = LocalDate.now(ZoneOffset.UTC).toString()
    }
    LocalDate currentDate = LocalDate.parse(currentDateStr, DateTimeFormatter.ISO_LOCAL_DATE)

    def rawWorkingHours = message.getProperty("working_hours_per_day")
    BigDecimal workingHoursPerDay = new BigDecimal("8.00") // default

    if (rawWorkingHours != null && rawWorkingHours.toString().trim()) {
        workingHoursPerDay = new BigDecimal(rawWorkingHours.toString())
    }
    
    workingHoursPerDay = workingHoursPerDay.setScale(2, RoundingMode.HALF_UP)
    message.setProperty("working_hours_per_day", workingHoursPerDay.toPlainString())

    def workingWeekStr = (message.getProperty("working_week") ?: "").toString().trim()
    if (!workingWeekStr) {
        workingWeekStr = "MON,TUE,WED,THU,FRI"
    }

    Set<DayOfWeek> workingDays = new HashSet<>()

    workingWeekStr.split(/[,;]+/).each { token ->
       def v = token.trim()
       if (!v) return

       DayOfWeek dow = null
       switch (v.toLowerCase()) {
           case "mon":
               dow = DayOfWeek.MONDAY
               break
           case "tue":
               dow = DayOfWeek.TUESDAY
               break
           case "wed":
               dow = DayOfWeek.WEDNESDAY
               break
           case "thu":
               dow = DayOfWeek.THURSDAY
               break
           case "fri":
               dow = DayOfWeek.FRIDAY
               break
           case "sat":
               dow = DayOfWeek.SATURDAY
               break
           case "sun":
               dow = DayOfWeek.SUNDAY
               break
       }

       if (dow != null) {
           workingDays.add(dow)
       }
    }

    if (workingDays.isEmpty()) {
        workingDays.add(DayOfWeek.MONDAY)
        workingDays.add(DayOfWeek.TUESDAY)
        workingDays.add(DayOfWeek.WEDNESDAY)
        workingDays.add(DayOfWeek.THURSDAY)
        workingDays.add(DayOfWeek.FRIDAY)
    }

    // Ensure the *current* date itself is a working day:
    // if not, jump forward until we hit the next working day.
    while (!workingDays.contains(currentDate.getDayOfWeek())) {
        currentDate = currentDate.plusDays(1)
    }

    // Decide how many hours to log in this iteration
    BigDecimal currentChunkHours = BigDecimal.ZERO

    if (days > 0L) {
        currentChunkHours = workingHoursPerDay
        days = days - 1L
    } else if (hoursRemaining.compareTo(BigDecimal.ZERO) > 0) {
        currentChunkHours = hoursRemaining
        hoursRemaining = BigDecimal.ZERO
    }

    currentChunkHours = currentChunkHours.setScale(2, RoundingMode.HALF_UP)

    boolean hasMoreTime = (days > 0L || hoursRemaining.compareTo(BigDecimal.ZERO) > 0)

    message.setProperty("recorded_hours", currentChunkHours.toPlainString())

    String timeSheetDateStr = currentDate.format(DateTimeFormatter.ISO_LOCAL_DATE) + "T00:00:00"
    message.setProperty("time_sheet_date", timeSheetDateStr)

    message.setProperty("business_days_remaining", days)
    message.setProperty("remaining_hours", hoursRemaining.toPlainString())
    message.setProperty("has_more_time", hasMoreTime)

    if (hasMoreTime) {
        LocalDate nextDate = currentDate.plusDays(1)

        while (!workingDays.contains(nextDate.getDayOfWeek())) {
            nextDate = nextDate.plusDays(1)
        }

        message.setProperty("current_date", nextDate.toString())
    }

    return message
}
