import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def activityTypeNote = message.getProperty("activity_type_note")
    def defaultActivityType = message.getProperty("activity_type")
    def wbsElement = message.getProperty("wbs_element_id")
    def workerId = message.getProperty("worker_id")

    def body = message.getBody(java.io.Reader)
    def slurper = new XmlSlurper()
    def root = slurper.parse(body)

    def resourceAssignments = root.A_ProjDmndResourceAssignment_Type
                            .to_Work
                            .A_ProjectDemandResource_Type

    def count = resourceAssignments.size()
    String earlyExitReason

    switch (count) {
        case 0:

            if(activityTypeNote){
                message.setProperty("activity_type", activityTypeNote)
            }
            
            
            if (!activityTypeNote){
                message.setProperty("activity_type", defaultActivityType)    
            }
            
            break
        case 1:
            def singleResourceAssignment = resourceAssignments[0]
            message.setProperty("activity_type", singleResourceAssignment.ActivityType.text())
            message.setProperty("delivery_org", singleResourceAssignment.ProjDmndRequestedDeliveryOrg.text())
            break
        default:
            if (!activityTypeNote) {
              earlyExitReason = "Multiple Roles Assigned to Worker $workerId for WBS Element $wbsElement and No Activity Type Specified in Worklog"
              break
            }

            def foundActivityForNote = resourceAssignments.find { it.ActivityType.text() == activityTypeNote }
            if (foundActivityForNote) {
              message.setProperty("activity_type", foundActivityForNote.ActivityType.text())
              message.setProperty("delivery_org", foundActivityForNote.ProjDmndRequestedDeliveryOrg.text())
              break
            }

            earlyExitReason = "Multiple Roles Assigned to Worker $workerId for WBS Element $wbsElement but None Match the Activity Type in Worklog $activityTypeNote"
            break
    }

    if (earlyExitReason) {
      message.setProperty("early_exit_reason", earlyExitReason)
    }

    return message
}