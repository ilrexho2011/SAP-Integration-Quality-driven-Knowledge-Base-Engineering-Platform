import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def json = new JsonSlurper().parse(body)

    def result = json.findAll { it.name.endsWith("WBS Elements")}

    message.setProperty("jira_fields_body", JsonOutput.toJson(result))
    return message
}