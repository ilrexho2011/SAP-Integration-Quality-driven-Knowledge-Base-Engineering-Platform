import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def projectName = message.getProperty("project_name")
    def customFieldName = "$projectName WBS Elements"
    
    def jiraFieldsRaw = message.getProperty("jira_fields_body") as String
    def jiraFields = new JsonSlurper().parseText(jiraFieldsRaw)

    def existingField = jiraFields.find { it -> it.name == customFieldName }
    
    if (existingField) {
        message.setProperty("custom_field_id", existingField.id)
    }

    message.setProperty("has_custom_field", (boolean) existingField)

    return message
}