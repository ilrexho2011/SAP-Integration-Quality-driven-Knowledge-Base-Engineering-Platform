import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def recordsRaw = message.getProperty("s4_timesheet_records")

    def records = new JsonSlurper().parseText(recordsRaw as String)

    message.setProperty("timesheetRecordCount", records.size())
    message.setProperty("timesheetRecordIndex", 0) 

    return message
}
