import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def body = message.getBody(java.io.Reader)

    def json = new JsonSlurper().parse(body)

    def issueTimestamp = json?.fields?.updated ?: ""

    message.setProperty("issue_timestamp", issueTimestamp)

    return message
}
