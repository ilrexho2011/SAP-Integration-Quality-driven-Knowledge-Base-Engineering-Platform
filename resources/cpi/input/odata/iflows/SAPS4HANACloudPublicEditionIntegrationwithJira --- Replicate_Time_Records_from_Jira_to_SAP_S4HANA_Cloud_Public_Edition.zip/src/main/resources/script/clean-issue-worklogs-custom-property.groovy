import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def issueWorklogsProperty = message.getProperty("issue_worklogs_custom_property")
    def issueWorklogs = message.getProperty("worklogs_for_issue_body")

    def slurper = new JsonSlurper()

    List trackedWorklogs = []
    if (issueWorklogsProperty) {
        def parsed = slurper.parseText(issueWorklogsProperty)
        trackedWorklogs = parsed ?: []
    }

    def issueWorklogsObj = issueWorklogs ? slurper.parseText(issueWorklogs) : [:]
    List jiraWorklogs = (issueWorklogsObj?.worklogs ?: []) as List

    // Build Set of IDs currently in Jira
    Set<String> jiraIds = (jiraWorklogs
        .collect { it?.id?.toString() }
        .findAll { it }) as Set

    // Determine deleted tracked worklogs (not present in Jira)
    Set<String> deletedIdSet = (trackedWorklogs
        .collect { it?.worklog_id?.toString() }
        .findAll { it && !jiraIds.contains(it) }) as Set

    // Keep only remaining worklogs
    List remainingWorklogs = trackedWorklogs.findAll { wl ->
        String id = wl?.worklog_id?.toString()
        // keep if no id OR not deleted
        !id || !deletedIdSet.contains(id)
    }

    String updatedJson = JsonOutput.toJson(remainingWorklogs)
    message.setProperty("issue_worklogs_custom_property", updatedJson)

    return message
}