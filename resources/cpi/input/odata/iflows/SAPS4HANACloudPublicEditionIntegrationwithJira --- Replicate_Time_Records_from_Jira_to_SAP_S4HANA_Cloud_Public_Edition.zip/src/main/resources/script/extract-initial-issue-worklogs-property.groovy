import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {

    def issueKey = (message.getProperty("issue_key"))
    def issuePayload = message.getProperty("issue_payload")

    def xml = new XmlSlurper().parseText(issuePayload)

    def issueNode = xml.Issue.find { it.IssueKey.text() == issueKey }

    def worklogsJson = issueNode ? issueNode.Worklogs.text() : ""
    
    boolean hasWorklogsKey = false
    
    if (issueNode) {
        hasWorklogsKey = (issueNode.Worklogs.size() > 0)
    }

    message.setProperty("issue_worklogs_custom_property", worklogsJson)
    message.setProperty("has_worklogs_key", hasWorklogsKey)

    return message
}
