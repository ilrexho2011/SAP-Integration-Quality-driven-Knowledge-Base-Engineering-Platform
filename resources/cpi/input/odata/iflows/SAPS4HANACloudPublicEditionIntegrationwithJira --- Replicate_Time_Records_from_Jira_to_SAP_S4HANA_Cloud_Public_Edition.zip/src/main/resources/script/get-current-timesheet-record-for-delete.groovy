import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

Message processData(Message message) {

    def recordsRaw = message.getProperty("s4_timesheet_records")
    int index = (message.getProperty("timesheetRecordIndex") ?: 0) as int

    if (!recordsRaw) {
        return message
    }

    def records = new JsonSlurper().parseText(recordsRaw as String)

    if (!(records instanceof List) || records.isEmpty()) {
        return message
    }

    if (index < 0 || index >= records.size()) {
        return message
    }

    def currentRecord = records[index]

    message.setProperty("current_timesheet_record", currentRecord)
    message.setProperty("timesheetRecordIndex", index + 1)

    return message
}
