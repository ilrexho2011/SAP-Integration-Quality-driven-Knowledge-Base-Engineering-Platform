import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        def customProjectFilter = message.getProperty("projects_query_filter") as String
        def fullFilterQuery = "substringof(ProjectDescription, 'JK:') and $customProjectFilter"
        
        messageLog.addCustomHeaderProperty("Projects not found matching filter", fullFilterQuery)
    }
    return message
}