import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil
import java.util.regex.Pattern
import groovy.json.JsonOutput
import java.time.OffsetDateTime
import java.time.Instant
import java.time.format.DateTimeFormatter

def Message processData(Message message) {
    String ACTIVITY_PREFIX = "[ACTIVITY_TYPE]:"
    def body = message.getBody(java.io.Reader)
    def response = new JsonSlurper().parse(body)

    def builder = new StreamingMarkupBuilder()
    def newXml = builder.bind { mkp ->
        mkp.Worklogs {

            response.worklogs.each { worklog ->

                def commentObj = worklog.comment
                def activityType = extractActivityType(commentObj, ACTIVITY_PREFIX)
                def authorId = worklog.author?.accountId ?: ""
                def startTime = worklog.started ?: ""
                def createTime = worklog.created ?: ""
                def updatedTime = worklog.updated ?: ""
                def timeSpendSeconds = worklog.timeSpentSeconds ?: 0
                def worklogId = worklog.id ?: ""
                def displayName = worklog.updateAuthor.displayName ?: ""
                def s4TimesheetRecordsList = worklog.properties?.find { it.key == 's4_timesheet_records' }?.value?.s4_timesheet_records_ids ?: []
                def s4TimesheetRecords = JsonOutput.toJson(s4TimesheetRecordsList)

                boolean isWorklogInitiliazedOnly = false
                isWorklogInitiliazedOnly = worklog.created == worklog.updated

                boolean hasS4Key = false

                if (worklog?.properties instanceof List) {
                    hasS4Key = worklog.properties.any { it?.key == "s4_timesheet_records" }
                }
                
                //worklog is created and replicated, but not updated
                if (hasS4Key && isWorklogInitiliazedOnly) {
                    return ""
                }

                def worklogLastProcessedTimestamp = worklog.properties?.find { it.key == 's4_timesheet_records' }?.value?.last_processed_timestamp ?: ""

                def fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ")

                Instant updatedInstant = OffsetDateTime.parse(updatedTime as String, fmt).toInstant()

                Instant lastProcessedInstant = (worklogLastProcessedTimestamp as String) ? OffsetDateTime.parse(worklogLastProcessedTimestamp as String, fmt).toInstant() : Instant.EPOCH

                def isUpdatedAfterLastProcessed = updatedInstant.isAfter(lastProcessedInstant)

                boolean worklogIsForUpdate = false
                
                //worklog is created and updated
                if (hasS4Key && !isWorklogInitiliazedOnly) {
                    if (isUpdatedAfterLastProcessed) { 
                        worklogIsForUpdate = true //updated worklog must be replicated
                    } else {
                        return "" //updated worklog is replicated
                    }
                }

                Worklog {
                    Id(worklogId)
                    AuthorId(authorId)
                    DisplayName(displayName)
                    Started(startTime)
                    Updated(updatedTime)
                    Created(createTime)
                    TimeSpentSeconds(timeSpendSeconds)
                    ActivityType(activityType)
                    S4TimesheetRecords(s4TimesheetRecords)
                    WorklogIsForUpdate(worklogIsForUpdate)
                }
            }
        }
    }

    message.setBody(XmlUtil.serialize(newXml))
    return message
}

/**
 * Extracts the Activity Type from a comment object.
 * The comment can be a String (plain text) or a Map (Jira rich text 'doc' format).
 *
 * @param commentObj The worklog.comment object (can be Map, String, or null)
 * @return The found activity type, or an empty string if not found.
 */
private String extractActivityType(Object commentObj, String prefix) {
    if (commentObj instanceof Map) {
        def contentList = commentObj.content
        if (contentList instanceof List) {
            return findActivityInContent(contentList, prefix)
        }
    } else if (commentObj instanceof String) {
        def commentString = (String) commentObj

        // Use regex to find the pattern: "[prefix]: value"
        // Pattern.quote() escapes special chars like '[' and ']' in the prefix
        // (.*) captures the value after the prefix
        def matcher = (commentString =~ /${Pattern.quote(prefix)}\s*(.*)/)

        if (matcher.find()) {
            def fullMatch = matcher.group(1)

            def value = fullMatch.split(/[\r\n]/)[0]
            return value.trim()
        }
    }
    return ""
}


/**
 * Recursively searches a JIRA 'doc' content list (rich text) for a text node
 * starting with the prefix.
 *
 * @param contentList The list of 'content' nodes from a rich text object.
 * @return The found activity type, or an empty string.
 */
private String findActivityInContent(List contentList, String prefix) {
    if (!contentList) {
        return ""
    }

    for (node in contentList) {
        if (node instanceof Map) {
            if (node.type == "text" && node.text?.startsWith(prefix)) {
                return node.text.substring(prefix.length()).trim()
            }

            if (node.content instanceof List) {
                def found = findActivityInContent(node.content, prefix)
                if (found) {
                    return found
                }
            }
        }
    }

    return ""
}