import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def projectPayloadRaw = message.getProperty("project_payload")
    def wbsElement = message.getProperty("wbs_element_id")

    def project = new XmlSlurper().parseText(projectPayloadRaw)
    def projectElement = project.A_EnterpriseProjectType.to_EnterpriseProjectElement.A_EnterpriseProjectElementType.find { it.ProjectElement == wbsElement }

    if (projectElement) {
      message.setProperty("wbs_element_uuid", projectElement.ProjectElementUUID.text())
    } else {
    message.setProperty("missing_project_element", true)
    }

    return message
}