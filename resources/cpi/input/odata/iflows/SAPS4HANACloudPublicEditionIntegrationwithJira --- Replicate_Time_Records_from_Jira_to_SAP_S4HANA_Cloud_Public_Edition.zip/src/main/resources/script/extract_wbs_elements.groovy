import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def xml = new XmlSlurper().parse(body)

    def projectElements = xml.A_EnterpriseProjectType
                             .to_EnterpriseProjectElement
                             .A_EnterpriseProjectElementType

    def subProjectElements = projectElements.findAll { 
        !it.ProjectElementDescription.text().contains("JK:")
    }

    message.setProperty("has_wbs_elements", projectElements.size() == 1 ? true : subProjectElements.size() > 0)
    return message
}