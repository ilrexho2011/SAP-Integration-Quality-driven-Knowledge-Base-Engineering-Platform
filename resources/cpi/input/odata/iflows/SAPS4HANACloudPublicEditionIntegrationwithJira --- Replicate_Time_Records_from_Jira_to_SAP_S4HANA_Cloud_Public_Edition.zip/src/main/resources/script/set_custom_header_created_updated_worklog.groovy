import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

  def messageLog = messageLogFactory.getMessageLog(message)

  if (messageLog != null) {

    def projectName = message.getProperty("project_name") as String
    def worklogIsForUpdate = message.getProperty("worklog_is_for_update")
    def headerMessage = worklogIsForUpdate == 'true' ? "Successfully Updated Worklog" : "Successfully Created Worklog"
    def worklogId = message.getProperty("worklog_id") as String
    def headerValue = "Project Name: ${projectName}, Worklog ID: ${worklogId}"

    if (worklogId != null && !worklogId.isEmpty() && projectName != null && !projectName.isEmpty()) {
      messageLog.addCustomHeaderProperty(headerMessage, headerValue)
    }
  }

  return message
}