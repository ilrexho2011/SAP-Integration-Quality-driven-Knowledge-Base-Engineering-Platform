import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import java.text.SimpleDateFormat
import java.util.TimeZone
import java.time.Instant

def Message processData(Message message) {

    def xmlString = (message.getProperty("project_issues_timestamp") ?: "") as String
    if (!xmlString) {
        def outFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm")
        outFmt.setTimeZone(TimeZone.getTimeZone("UTC"))
        def defaultDate = outFmt.format(new Date(0L))

        message.setProperty("latest_updated_issue_timestamp", defaultDate)
        return message
    }
    
    def root = new XmlSlurper(false, false).parseText(xmlString)

    // Parse timestamp string to Instant
    def parseToInstant = { String ts ->
        def patterns = [
            "yyyy-MM-dd'T'HH:mm:ss.SSSZ", // e.g. 2025-11-25T22:36:00.000+0200
            "yyyy-MM-dd'T'HH:mm:ssZ"      // e.g. 2025-11-24T13:26:35+0000
        ]

        for (p in patterns) {
            try {
                def sdf = new SimpleDateFormat(p)
                sdf.setLenient(false)
                return sdf.parse(ts).toInstant()
            } catch (Exception ignored) {
                // try next pattern
            }
        }
        throw new IllegalArgumentException("Unsupported timestamp format: " + ts)
    }

    Instant latestInstant = null

    root.issue.each { issueNode ->
        def tsText = issueNode.issueLatestTimeStamp.text()
        if (tsText) {
            def inst = parseToInstant(tsText)
            if (latestInstant == null || inst.isAfter(latestInstant)) {
                latestInstant = inst
            }
        }
    }

    // Prepare formatter for JQL-compatible date
    def outFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm")
    outFmt.setTimeZone(TimeZone.getTimeZone("UTC"))

    String jqlDate

    if (latestInstant != null) {
        jqlDate = outFmt.format(Date.from(latestInstant))
    } else {
        jqlDate = outFmt.format(new Date(0L))
    }

    message.setProperty("latest_updated_issue_timestamp", jqlDate)

    return message
}
