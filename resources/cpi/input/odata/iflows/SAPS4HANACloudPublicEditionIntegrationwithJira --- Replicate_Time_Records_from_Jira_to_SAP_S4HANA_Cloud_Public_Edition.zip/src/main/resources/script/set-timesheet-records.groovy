import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.ZonedDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

def Message processData(Message message) {
    
    def body = message.getBody(java.io.Reader)
    def timesheetEntryCollection = new XmlSlurper().parse(body);

    def timesheetRecord = timesheetEntryCollection.TimeSheetEntry.TimeSheetRecord.text()

    def timesheetRecordsRaw = message.getProperty('s4_timesheet_records')

    def json = new JsonSlurper().parseText(timesheetRecordsRaw)

    json.add(timesheetRecord)

    message.setProperty('s4_timesheet_records', JsonOutput.toJson(json))
    
    def now = ZonedDateTime.now(ZoneOffset.UTC)
    def jql_format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    def worklog_last_processed_timestamp = now.format(jql_format)

    message.setProperty("worklog_last_processed_timestamp", worklog_last_processed_timestamp)

    return message
}
