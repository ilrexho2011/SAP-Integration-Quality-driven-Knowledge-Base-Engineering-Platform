import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def map = message.getProperties()
    def logException = map.get("ExceptionLogging")?.equalsIgnoreCase("true") // Determine if logging is enabled

    if (logException) {
        def ex = map.get("CamelExceptionCaught")
        if (ex != null) {
            handleException(message, map)
        } else {
            handleMessageBody(message)
        }
    }

    return message
}

def handleException(Message message, def map) {
    def ex = map.get("CamelExceptionCaught")
    def attachID = "Error Details"
    def errordetails = "The process failed due to the following error: ${ex.toString()}"

    addAttachment(message, attachID, errordetails)
}

def handleMessageBody(Message message) {
    def messageBody = message.getBody(String)
    def attachID = "Error Details"
    def errordetails = "Message Content: \n${messageBody}"

    addAttachment(message, attachID, errordetails)
}

def addAttachment(Message message, String attachID, String errorMessage) {
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.addAttachmentAsString(attachID, errorMessage, "text/plain")
    }
}