import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import groovy.xml.StreamingMarkupBuilder
import groovy.xml.XmlUtil

def Message processData(Message message) {

    def issueWorklogsProperty = message.getProperty("issue_worklogs_custom_property") as String
    def issueWorklogs = message.getProperty("worklogs_for_issue_body") as String

    def slurper = new JsonSlurper()

    def issueWorklogsPropertyObj = issueWorklogsProperty ? slurper.parseText(issueWorklogsProperty) : [:]
    List trackedWorklogs = (issueWorklogsPropertyObj ?: []) as List

    def issueWorklogsObj = issueWorklogs ? slurper.parseText(issueWorklogs) : [:]
    List jiraWorklogs = (issueWorklogsObj?.worklogs ?: []) as List

    // IDs currently in Jira
    Set<String> jiraIds = (jiraWorklogs
            .collect { it?.id?.toString() }
            .findAll { it }) as Set

    // "Deleted" = present in custom property but NOT present in Jira response
    List deletedWorklogs = trackedWorklogs.findAll { wl ->
        String id = wl?.worklog_id?.toString()
        id && !jiraIds.contains(id)
    }

    def builder = new StreamingMarkupBuilder()
    def newXml = builder.bind { mkp ->
        mkp.Worklogs {
            deletedWorklogs.each { wl ->
                String worklogId = wl?.worklog_id?.toString() ?: ""
                String companyCode = wl?.company_code?.toString() ?: ""
                String workerId = wl?.worker_id?.toString() ?: ""

                def recs = wl?.s4_timesheet_records
                List<String> recList = (recs instanceof List)
                        ? recs.collect { it?.toString() }.findAll { it }
                        : []
                String s4TimesheetRecordsJson = JsonOutput.toJson(recList)

                Worklog {
                    Id(worklogId)
                    S4TimesheetRecords(s4TimesheetRecordsJson)
                    CompanyCode(companyCode)
                    WorkerId(workerId)
                }
            }
        }
    }

    message.setBody(XmlUtil.serialize(newXml))

    return message
}
