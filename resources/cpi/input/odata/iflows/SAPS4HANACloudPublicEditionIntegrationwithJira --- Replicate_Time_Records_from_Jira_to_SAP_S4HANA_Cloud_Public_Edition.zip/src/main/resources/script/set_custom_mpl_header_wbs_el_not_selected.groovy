import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {

        def projectName = message.getProperty("project_name") as String
        def earlyExitReason = message.getProperty("early_exit_reason") as String
        def issue = message.getProperty("issue_key") as String
        def headerValue = ["Project": " " + projectName + " ","Issue":  " " + issue + " ","Reason": " " + earlyExitReason].toString()
        
        if (projectName != null && !projectName.isEmpty()) {
            messageLog.addCustomHeaderProperty("Did Not Replicate Time Records", headerValue)
        }
    }
    return message
}