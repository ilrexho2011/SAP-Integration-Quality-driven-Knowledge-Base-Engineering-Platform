import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {

        def business_partner = message.getProperty("business_partner") as String;
        def reason = message.getProperty("early_exit_reason") as String;
        def headerValue = ["Business Partner Id": " " + business_partner + " ", "Reason": " " + reason].toString()
        if (business_partner != null && !business_partner.isEmpty()) {
            messageLog.addCustomHeaderProperty("Failed to Replicate Employee", headerValue);
        }
    }
    return message;
}