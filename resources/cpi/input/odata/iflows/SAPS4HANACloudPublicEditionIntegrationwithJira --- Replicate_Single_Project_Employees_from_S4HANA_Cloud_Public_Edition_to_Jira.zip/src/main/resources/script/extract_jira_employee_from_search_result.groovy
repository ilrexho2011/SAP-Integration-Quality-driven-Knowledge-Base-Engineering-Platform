import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def jiraEmployeeSearchResult = new JsonSlurper().parse(body)

    if (jiraEmployeeSearchResult.size() == 0) {
        message.setProperty("jira_employee_exists", false)

        return message
    }

    def jiraEmployee = jiraEmployeeSearchResult[0]
    message.setProperty("jira_employee_id", jiraEmployee.accountId)

    return message
}