import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {

        def businessPartner = message.getProperty("business_partner") as String;
        if (businessPartner != null && !businessPartner.isEmpty()) {
            messageLog.addCustomHeaderProperty("Replicated Business Partner", businessPartner);
        }
    }
    return message;
}