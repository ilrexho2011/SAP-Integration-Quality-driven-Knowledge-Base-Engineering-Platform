import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    def rawJiraProducts = message.getProperty("jira_products")
    def jiraProducts = rawJiraProducts.split(",").collect { it.trim() }

    message.setProperty("jira_products", JsonOutput.toJson(jiraProducts))
    return message
}