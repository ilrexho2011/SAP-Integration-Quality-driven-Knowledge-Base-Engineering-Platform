import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def jiraEmployeeResponse = new JsonSlurper().parse(body)

    message.setProperty("jira_employee_id", jiraEmployeeResponse.accountId)

    return message
}