import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        def project = message.getProperty("project_id") as String;
        
        messageLog.addCustomHeaderProperty("Project not found", project);
    }
    return message;
}