import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def body = message.getBody(java.io.Reader)
    def businessPartnerXml = new XmlSlurper().parse(body)

    message.setProperty("business_partner", businessPartnerXml.A_BusinessPartnerType.BusinessPartner.text())

    def emailAddresses = businessPartnerXml.A_BusinessPartnerType.to_BusinessPartnerAddress.A_BusinessPartnerAddressType.to_EmailAddress.A_AddressEmailAddressType
    def defaultEmail = emailAddresses.find { it.IsDefaultEmailAddress.text() == 'true' }

    if (!defaultEmail) {
        message.setProperty("has_email", false)
        return message
    }
    message.setProperty("business_partner_address_id", businessPartnerXml.A_BusinessPartnerType.to_BusinessPartnerAddress.A_BusinessPartnerAddressType.AddressID.text())
    message.setProperty("employee_email", defaultEmail.EmailAddress.text())
    message.setProperty("email_address_person", defaultEmail.Person.text())
    message.setProperty("email_address_ordinal_number", defaultEmail.OrdinalNumber.text())
    message.setProperty("linked_jira_employee_id", defaultEmail.AddressCommunicationRemarkText.text())

    return message
}