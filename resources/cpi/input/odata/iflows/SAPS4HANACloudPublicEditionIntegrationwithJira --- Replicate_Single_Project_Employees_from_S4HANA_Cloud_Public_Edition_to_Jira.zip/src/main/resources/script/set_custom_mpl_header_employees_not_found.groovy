import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        def project = message.getProperty("project_id") as String
		
		def filter = "Project: " + project
        
        messageLog.addCustomHeaderProperty("No Employees found for filter", filter)
    }
    return message
}